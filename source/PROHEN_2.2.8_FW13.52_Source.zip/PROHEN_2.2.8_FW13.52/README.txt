PROHEN 2.2.8 BETA - PS4 13.52 - REPAIR CANDIDATE 5

This candidate addresses the report that selecting Friends still opens the
PSN sign-in/update screen. It has not been tested on a physical PS4. This
bundle accompanies the owner-authorized publication of build 5 to GitHub Pages.

WHAT THE REPORT DOES AND DOES NOT ESTABLISH
The native Friends route is still being reached. The supplied build 3 log
previously confirmed a loaded plugin and core menu hooks, but unavailable
optional Mono APIs. No complete build 4 status log was supplied with this
new report, so it does not establish whether build 4's helper loaded, whether
the panel renderer bound, or which Friends method received the selection.

CODE CHANGES
- Look for a declared instance IconSelect() returning void on a recognized
  TopMenu SystemAreaIconFriend/SystemAreaIconFriends class. This is an earlier
  selection callback than the old LaunchPlugin-only replacement.
- Require the earlier callback before claiming an installed local shortcut.
  If only LaunchPlugin exists, leave the normal Friends action/title alone,
  log that the earlier entry is unavailable and direct users to Settings.
- Also hook a valid declared LaunchPlugin() when available, covering callers
  that launch directly. The replacement never calls the original PSN action.
- Install the local shortcut independently of the panel renderer. Missing
  panel bindings now produce local feedback when a hooked entry is selected.
- Retry panel binding on selection so delayed UI metadata can become usable.
- Keep the menu metadata capability separate from the two panel field APIs.
- Validate signatures, class namespace, executable bounds and complete native
  instructions. Reject unknown classes, ambiguity and overlapping methods.
  Verify both hook writes and roll both back if either fails; failed rollback
  blocks retry and requests a reboot.
- Record a bounded list of actual Friends-related classes/methods and report
  when the replacement callback runs. Unknown classes are logged, not patched.
- Remove the stale candidate-3 note from the native Settings description.

REQUIRED CONSOLE CHECK
1. Reboot before loading this payload. An existing HEN session cannot replace
   the loaded modules merely by overwriting files or rerunning the payload.
2. Keep enable_plugins=1 and upload_prx=1 in the saved hen.ini or USB override.
   The matching payload installs plugin_mono.prx and plugin_mono_api.prx.
3. Expect "PROHEN build 5: ShellUI plugin loaded." The first status line
   identifies PROHEN 2.2.8 BETA local fix candidate 5.
4. First try Settings > PROHEN Settings > System Overlay, then return to the
   home screen. Record whether the panel appears.
5. Check the top function row. The PROHEN menu uses the PS Plus position.
   The Friends title becomes System Overlay only after its early hook verifies.
6. Select that shortcut once. Look for:
   "Friends IconSelect + LaunchPlugin hooks verified" (or IconSelect alone)
   "Friends selection intercepted; using local overlay action".
   If the early entry does not exist in this firmware's actual class layout,
   the shortcut remains unavailable; use Settings and send the metadata log.
7. Provide the complete /data/hen/prohen-status.log after the failed selection,
   including any helper, metadata, panel and callback messages. Report whether
   the System Overlay option in PROHEN Settings works. This distinguishes a
   missing dispatch hook from an unavailable renderer or a later PSN gate.

This local feature does not require PSN sign-in or a firmware update. The
code does not fake an account sign-in or change account/update checks globally.
Do not infer real-console success from the desktop selection-flow test.

FILES AND VERSION
binaries/prohen.bin is the complete payload with the matching plugins.
binaries/plugin_mono.prx is the main ShellUI plugin.
binaries/plugin_mono_api.prx is the optional native-link API companion.
Install both matching PRXs for manual replacement; they live under /data/hen.
Version remains 2.2.8 BETA. The System Information addition, when available,
preserves the native firmware text and appends " | PROHEN 2.2.8 BETA".
The renderer is a home-screen information panel. No game/app tile is installed.
Kernel sources, firmware offsets and the default hen.ini are unchanged.

BUILD AND VERIFICATION
Install GCC/G++, GNU binutils/make, Python 3, xxd, Clang 18 and LLD 18. Obtain
OpenOrbis headers/stubs and create-fself from the official v0.5.3
toolchain-llvm-18.2 release. Set OO_PS4_TOOLCHAIN to OpenOrbis/PS4Toolchain and
run bash build-test.sh. The SDK and native component sources are included.
The build does not contact a console or publish anything.

Tests cover the modeled earlier PSN selection flow, early/direct local hooks,
panel-binding independence/retry, missing or ambiguous methods, unsupported
firmware, wrong class/signature, native bounds/instruction guards, alias and
overlap cases, rollback failure, Settings controls, timers, version display,
delayed startup and optional helper ABI/import isolation.
Desktop checks cannot prove which callback this console actually uses.
verification/selection-contract.txt identifies the public interface reference.
SOURCE_REVISIONS.json retains the upstream source pins.

ROLLBACK
Reboot, then load original HEN with upload_prx=1 to restore its bundled plugins.
If ShellUI cannot start, remove or replace /data/hen/plugin_mono.prx using an
existing recovery environment. The companion has no independent auto-start
entry; the main plugin requests it only when needed.

CREDITS
This is a custom fork of Scene-Collective HEN 2.2.0 BETA, not an official HEN
release. Credits: Scene-Collective, illusiony, Al-Azif, raw13g, OSM-Made and the
original contributors. The native panel/DisplayVersion interface research is
from OSM-Made's Orbis-Toolbox. Keep all original licences and notices. No Sony
firmware executable or managed assembly is included in this source package.
