PROHEN 2.2.8 BETA - PS4 13.52 - REPAIR CANDIDATE 4

Build 3's supplied console log confirms that plugin_mono loaded, verified its
core menu hook writes and completed startup. The overlay and version additions
stopped because runtime lookup could not find the optional Mono APIs.
The log does not confirm that the shortcut was visible on the home screen.

BUILD 4 CHANGE
Keep the verified core-menu/startup code and the existing optional API lookup.
When runtime symbol lookup fails, load plugin_mono_api.prx as an optional
companion. The PS4 native linker binds its 14 Mono imports using the same
mechanism as the core plugin's working imports. A versioned entry point copies
a complete, typed API table to the main plugin. No firmware offsets are added.

The companion is deliberately independent of plugin_mono's load dependencies.
If a Mono API really is unavailable, the helper can fail without preventing the
core menu plugin from loading. Missing file/import, entry lookup, ABI and
incomplete-table failures are logged explicitly. This addresses the lookup
failure path; actual loading and UI behavior on 13.52 require a PS4 test.

The bounded /data/hen/prohen-status.log now records the missing lookup anchor,
module-list errors, the helper load result, and successful native-link binding.
Successful System Information updates also receive a verification log entry.

FILES
binaries/prohen.bin is the full payload with all matching bundled plugins.
binaries/plugin_mono.prx is the main ShellUI plugin.
binaries/plugin_mono_api.prx is the matching optional API companion.
The installer writes both under /data/hen/ when upload_prx=1. Do not mix them
with an earlier build. For manual plugin replacement, copy both matching PRXs;
replacing a file does not update a module that is already loaded.

CONSOLE CHECK
1. Reboot before loading build 4. An existing HEN session prevents another
   payload from replacing it during the same boot.
2. Keep enable_plugins=1 and upload_prx=1 in the existing /data/hen/hen.ini or
   USB override. Saved settings are reported without being overwritten.
3. Expect "PROHEN build 4: ShellUI plugin loaded." If normal Mono export
   lookup is unavailable, the status log should say:
   "14 optional APIs bound by native-link helper, handle <number>".
4. Press Up to the home screen's top function row. The PROHEN shortcut uses
   the PS Plus position; the payload does not install a game/app tile.
5. In PROHEN Settings, select System Overlay, then return to the home screen.
   A successfully installed Friends shortcut can also toggle the panel.
6. Check Settings > System > System Information for the native firmware text
   plus " | PROHEN 2.2.8 BETA".

If a feature still fails, provide the complete new /data/hen/prohen-status.log.
Its first line must identify candidate 4. Report whether PROHEN Settings exists
and whether the PS Plus-position shortcut is visible. A failed helper load now
has an explicit error code. Do not infer that the Mono APIs are actually absent
from the older generic "APIs unavailable" message alone.

RETAINED BUILD 3 REPAIRS
- Preserve the Friends slot before constructing ShellUI's menu.
- Preserve the offline PS Plus entry used for PROHEN.
- Wait for Mono/app metadata, retry delayed startup and prevent reentry.
- Keep Settings panel controls independent of the Friends shortcut; rename
  Friends only after the shortcut hook is successfully installed.
- Try the alternative PUI/UI2 assembly when required methods are missing.
- Preflight critical menu methods and verify action/title/icon/Settings writes.
- Bound notification copies and retain a bounded setup-status history.

VERSION AND SCOPE
Menu title: PROHEN. Settings page: PROHEN Settings. Version: 2.2.8 BETA.
The native information panel and version additions require firmware 13.52.
The panel is shown on the home screen. The Messages entry remains hidden.
Kernel sources, firmware offsets and default hen.ini match the published
build 3 baseline. Only the installer plugin list/path gains the companion.
This candidate accompanies the owner-authorized PROHEN 2.2.8 GitHub Pages publication.

ROLLBACK
Reboot, then load original HEN with upload_prx=1 to restore its bundled plugins.
If ShellUI cannot start, remove or replace /data/hen/plugin_mono.prx from an
existing recovery environment. The optional helper has no independent startup
entry in plugins.ini and is only requested by the main plugin.

BUILD AND VERIFICATION
Install GCC/G++, GNU binutils/make, Python 3, xxd, Clang 18 and LLD 18. Obtain
OpenOrbis headers/stubs and create-fself from the official v0.5.3
toolchain-llvm-18.2 release. Set OO_PS4_TOOLCHAIN to OpenOrbis/PS4Toolchain and
run bash build-test.sh. The SDK and native component sources are included.
The build does not install packages, contact a console or publish anything.

Tests cover the original overlay/version/startup behavior, failure of the Mono
lookup anchor, optional helper fallback, reentrant module callbacks, bad or
missing helpers, ABI/size validation, incomplete API tables and partial direct
capabilities. Import inspection proves the 14 extra Mono symbols are isolated
in the helper, not mandatory imports or a dependency of the main plugin.
The helper ABI test verifies addresses without making Mono calls.
Desktop checks do not prove native helper loading, panel visibility or input
behavior on physical hardware. SOURCE_REVISIONS.json lists the upstream pins.

CREDITS AND LICENSES
This is a custom fork of Scene-Collective HEN 2.2.0 BETA, not an official HEN
release. Credits: Scene-Collective, illusiony, Al-Azif, raw13g, OSM-Made and the
original HEN contributors. OSM-Made's Orbis-Toolbox documents the native panel
and DisplayVersion API. Keep all bundled LICENSE files and notices. Plugin
additions use the plugin project's MIT terms; server components and libjbc
retain their GPL notices. No Sony firmware executable or managed assembly is
included. Unchanged upstream source is included for rebuilding.
