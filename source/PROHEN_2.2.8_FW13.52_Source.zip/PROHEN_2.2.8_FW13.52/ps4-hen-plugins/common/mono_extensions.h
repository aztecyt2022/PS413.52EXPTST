#pragma once
#include <stddef.h>
#include <stdint.h>

// The main plugin keeps these imports optional. The companion binds them
// through the same native linker that resolves the core Mono imports.
#define PROHEN_MONO_EXTENSIONS_ABI 0x50520001u
#define PROHEN_MONO_EXTENSION_FIELDS(X) \
    X(class_get_field_from_name, mono_class_get_field_from_name) \
    X(field_get_value, mono_field_get_value) \
    X(class_get_methods, mono_class_get_methods) \
    X(method_get_name, mono_method_get_name) \
    X(method_signature, mono_method_signature) \
    X(signature_get_param_count, mono_signature_get_param_count) \
    X(signature_get_return_type, mono_signature_get_return_type) \
    X(type_get_type, mono_type_get_type) \
    X(method_get_flags, mono_method_get_flags) \
    X(image_get_table_info, mono_image_get_table_info) \
    X(table_info_get_rows, mono_table_info_get_rows) \
    X(class_get, mono_class_get) \
    X(class_get_name, mono_class_get_name) \
    X(class_get_namespace, mono_class_get_namespace)

struct ProHENMonoExtensions {
    void* (*class_get_field_from_name)(const void*, const char*);
    void (*field_get_value)(const void*, const void*, void*);
    void* (*class_get_methods)(const void*, void**);
    const char* (*method_get_name)(const void*);
    void* (*method_signature)(const void*);
    uint32_t (*signature_get_param_count)(const void*);
    void* (*signature_get_return_type)(const void*);
    int (*type_get_type)(const void*);
    uint32_t (*method_get_flags)(const void*, uint32_t*);
    const void* (*image_get_table_info)(const void*, int);
    int (*table_info_get_rows)(const void*);
    void* (*class_get)(const void*, uint32_t);
    const char* (*class_get_name)(const void*);
    const char* (*class_get_namespace)(const void*);
};

typedef int (*ProHENMonoExtensionProvider)(uint32_t abi, size_t table_size,
                                          struct ProHENMonoExtensions* table);
