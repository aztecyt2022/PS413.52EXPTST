#include <cassert>
#include <cstring>
#include <cstdio>
#include "../plugin_mono_api/source/exports.c"

// The provider only transfers addresses. No runtime function should execute.
void* mono_class_get_field_from_name(const void*,const char*) { assert(false);return nullptr; }
void mono_field_get_value(const void*,const void*,void*) { assert(false); }
void* mono_class_get_methods(const void*,void**) { assert(false);return nullptr; }
const char* mono_method_get_name(const void*) { assert(false);return nullptr; }
void* mono_method_signature(const void*) { assert(false);return nullptr; }
uint32_t mono_signature_get_param_count(const void*) { assert(false);return 0; }
void* mono_signature_get_return_type(const void*) { assert(false);return nullptr; }
int mono_type_get_type(const void*) { assert(false);return 0; }
uint32_t mono_method_get_flags(const void*,uint32_t*) { assert(false);return 0; }
const void* mono_image_get_table_info(const void*,int) { assert(false);return nullptr; }
int mono_table_info_get_rows(const void*) { assert(false);return 0; }
void* mono_class_get(const void*,uint32_t) { assert(false);return nullptr; }
const char* mono_class_get_name(const void*) { assert(false);return nullptr; }
const char* mono_class_get_namespace(const void*) { assert(false);return nullptr; }

int main() {
    ProHENMonoExtensions table={};
    const ProHENMonoExtensions empty=table;
    assert(ProHENGetMonoExtensions(PROHEN_MONO_EXTENSIONS_ABI+1,sizeof(table),&table)<0);
    assert(!memcmp(&table,&empty,sizeof(table)));
    assert(ProHENGetMonoExtensions(PROHEN_MONO_EXTENSIONS_ABI,sizeof(table)-1,&table)<0);
    assert(!memcmp(&table,&empty,sizeof(table)));
    assert(ProHENGetMonoExtensions(PROHEN_MONO_EXTENSIONS_ABI,sizeof(table),nullptr)<0);
    assert(ProHENGetMonoExtensions(PROHEN_MONO_EXTENSIONS_ABI,sizeof(table),&table)==0);
#define VERIFY_FIELD(field,symbol) assert(table.field==symbol);
    PROHEN_MONO_EXTENSION_FIELDS(VERIFY_FIELD)
#undef VERIFY_FIELD
    puts("PASS: helper rejects incompatible ABI/size without writes and transfers all 14 correctly typed API addresses without invoking Mono.");
}
