"""Guard the native plugin's optional-feature import boundary."""
import re
import subprocess
import sys
from pathlib import Path

header = Path(__file__).parent.parent / "plugin_mono/source/mono_optional.h"
optional = set(re.findall(r"^#define (mono_\w+) ", header.read_text(), re.MULTILINE))
symbols = subprocess.check_output(["readelf", "-Ws", sys.argv[1]], text=True)
imports = {line.split()[-1] for line in symbols.splitlines() if " UND " in line}
assert len(optional) == 14
assert not optional & imports, f"Optional APIs became mandatory: {optional & imports}"
assert {"mono_get_root_domain", "mono_runtime_invoke"} <= imports, "Core Mono imports missing"
bridge_symbols = subprocess.check_output(["readelf", "-Ws", sys.argv[2]], text=True)
bridge_imports = {line.split()[-1] for line in bridge_symbols.splitlines() if " UND " in line}
assert optional <= bridge_imports, f"Helper imports missing: {optional - bridge_imports}"
assert re.search(r"GLOBAL\s+DEFAULT\s+\d+\s+ProHENGetMonoExtensions", bridge_symbols), "Helper entry is not exported"
needed = subprocess.check_output(["readelf", "-d", sys.argv[1]], text=True)
assert "plugin_mono_api" not in needed, "Helper became a main-plugin dependency"
print("PASS: all 14 extra Mono imports are isolated in the optional helper; the main plugin retains only its core Mono imports.")
