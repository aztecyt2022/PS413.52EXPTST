#include <cassert>
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <deque>

struct OrbisKernelSwVersion { size_t Size; char VersionString[28]; uint32_t Version; };
static int sceKernelGetSystemSwVersion(OrbisKernelSwVersion*);
#define PROHEN_INFO_TEST
#include "../plugin_mono/source/shellui_patch/prohen_info.c"

struct Method { uint32_t args, flags; int type; };
static Method instance_get{0, 0x10, 0x12}, display_get{0, 0, 0x0e}, display_set{1, 0, 1};
static int app, klass, instance, instance_property, display_property;
void* Root_Domain = &app;
void* App_Exe = &app;
void* MSCorlib = nullptr;
static uint32_t firmware;
static int firmware_error, writes, allocations, frees;
static bool missing_class, missing_property, missing_getter, missing_setter;
static bool no_instance, no_display, utf8_failure, allocation_failure, corrupt_set;
static Method* throw_method;
static std::string current;
static std::deque<std::string> managed_strings;

static int sceKernelGetSystemSwVersion(OrbisKernelSwVersion* v) {
    assert(v->Size == sizeof(*v)); v->Version = firmware; return firmware_error;
}
void* mono_class_from_name(const void*, const char* space, const char* name) {
    assert(!strcmp(space, "Sce.Vsh.ShellUI.AppSystem"));
    assert(!strcmp(name, "SystemSoftwareVersionInfo"));
    return missing_class ? nullptr : &klass;
}
void* mono_class_get_property_from_name(const void*, const char* name) {
    if (missing_property) return nullptr;
    return !strcmp(name,"Instance") ? &instance_property : &display_property;
}
void* mono_property_get_get_method(const void* p) {
    if (missing_getter) return nullptr;
    return p == &instance_property ? &instance_get : &display_get;
}
void* mono_property_get_set_method(const void*) { return missing_setter ? nullptr : &display_set; }
void* mono_method_signature(const void* p) { return const_cast<void*>(p); }
uint32_t mono_signature_get_param_count(const void* p) { return static_cast<const Method*>(p)->args; }
void* mono_signature_get_return_type(const void* p) { return const_cast<void*>(p); }
int mono_type_get_type(const void* p) { return static_cast<const Method*>(p)->type; }
uint32_t mono_method_get_flags(const void* p, uint32_t*) { return static_cast<const Method*>(p)->flags; }
void* mono_runtime_invoke(const void* method, const void* object, const void* args[], const void* exc[]) {
    assert(exc); *exc = nullptr;
    if (method == throw_method) { *exc=&app; return nullptr; }
    if (method == &instance_get) { assert(!object); return no_instance ? nullptr : &instance; }
    assert(object == &instance);
    if (method == &display_get) {
        if (no_display) return nullptr;
        managed_strings.push_back(current); return &managed_strings.back();
    }
    assert(method == &display_set && args && args[0]);
    ++writes;
    current = *static_cast<const std::string*>(args[0]);
    if (corrupt_set && writes == 1) current = "unexpected";
    return nullptr;
}
char* mono_string_to_utf8(const void* p) {
    if (utf8_failure) return nullptr;
    ++allocations; return strdup(static_cast<const std::string*>(p)->c_str());
}
void mono_free(const void* p) { ++frees; free(const_cast<void*>(p)); }
void* mono_string_new(const void*, const char* text) {
    if (allocation_failure) return nullptr;
    managed_strings.emplace_back(text); return &managed_strings.back();
}
static void reset() {
    Root_Domain=&app; firmware=0x13520001; firmware_error=0;
    writes=allocations=frees=0; current="13.52"; managed_strings.clear();
    missing_class=missing_property=missing_getter=missing_setter=false;
    no_instance=no_display=utf8_failure=allocation_failure=corrupt_set=false; throw_method=nullptr;
    instance_get={0,0x10,0x12}; display_get={0,0,0x0e}; display_set={1,0,1};
}
static bool apply() { bool result=ProHENApplySystemVersion(&app); assert(allocations==frees); return result; }
static void unchanged() { assert(!apply()); assert(writes==0 && current=="13.52"); }

int main() {
    reset(); assert(apply()); assert(current=="13.52 | PROHEN 2.2.8 BETA" && writes==1);
    assert(apply()); assert(writes==1);
    current="13.52 | PROHEN 2.1.0"; assert(apply()); assert(current=="13.52 | PROHEN 2.2.8 BETA");
    current="Version 13.52"; assert(apply()); assert(current=="Version 13.52 | PROHEN 2.2.8 BETA");
    reset(); instance_get.type=0x13; assert(apply()); assert(current=="13.52 | PROHEN 2.2.8 BETA");
    puts("PASS: native firmware text is preserved; current PROHEN version is appended once and older PROHEN suffixes are replaced.");
    reset(); firmware=0x13500000; unchanged();
    reset(); firmware=0x14000000; unchanged();
    reset(); firmware_error=-1; unchanged();
    reset(); Root_Domain=nullptr; unchanged();
    reset(); assert(!ProHENApplySystemVersion(nullptr)); assert(writes==0);
    reset(); missing_class=true; unchanged();
    reset(); missing_property=true; unchanged();
    reset(); missing_getter=true; unchanged();
    reset(); missing_setter=true; unchanged();
    reset(); no_instance=true; unchanged();
    reset(); no_display=true; unchanged();
    reset(); display_set.args=2; unchanged();
    reset(); display_get.type=8; unchanged();
    reset(); instance_get.flags=0; unchanged();
    reset(); instance_get.type=8; unchanged();
    reset(); throw_method=&instance_get; unchanged();
    reset(); throw_method=&display_get; unchanged();
    reset(); utf8_failure=true; unchanged();
    reset(); allocation_failure=true; unchanged();
    reset(); current=""; assert(!apply()); assert(writes==0 && current.empty());
    reset(); current=std::string(155,'x'); assert(!apply()); assert(writes==0 && current.size()==155);
    puts("PASS: unsupported firmware, missing/invalid metadata, managed exceptions, allocation failures and oversized labels leave the native display unchanged.");
    reset(); corrupt_set=true; assert(!apply()); assert(current=="13.52" && writes==2);
    reset(); throw_method=&display_set; assert(!apply()); assert(current=="13.52");
    puts("PASS: an unexpected setter result rolls back; setter exceptions are contained; temporary UTF-8 buffers are freed.");
}
