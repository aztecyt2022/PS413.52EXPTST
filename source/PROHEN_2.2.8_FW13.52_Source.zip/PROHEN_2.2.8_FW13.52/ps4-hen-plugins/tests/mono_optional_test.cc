#include <cassert>
#include <cstdint>
#include <cstddef>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
typedef int32_t OrbisKernelModule;
static int sceKernelGetModuleList(OrbisKernelModule*,size_t,size_t*);
static int sceKernelDlsym(int,const char*,void**);
static int sceKernelLoadStartModule(const char*,size_t,const void*,unsigned,const void*,int*);
static int sceKernelStopUnloadModule(int,size_t,const void*,unsigned,const void*,int*);
static int sys_dynlib_dlsym(int,const char*,void*);
#include "../common/path.h"
#define PROHEN_OPTIONAL_TEST
#include "../plugin_mono/source/mono_optional.c"

static bool list_error, oversized, module_missing, bridge_missing, entry_missing;
static bool raw_only, partial_table, reenter;
static int provider_error, start_result;
static const char* missing;
static unsigned loads, unloads, provider_calls;
static std::vector<std::string> notices;
static void dummy() {}
static bool logged(const char* part) {
    for(const auto& line:notices) if(line.find(part)!=std::string::npos) return true;
    return false;
}
static int provider(uint32_t abi,size_t size,ProHENMonoExtensions* table) {
    ++provider_calls;
    assert(abi==PROHEN_MONO_EXTENSIONS_ABI && size==sizeof(*table));
    if(reenter) assert(!ProHENResolveMonoExtensions());
    if(provider_error) return provider_error;
#define TEST_FIELD(field,symbol) table->field=reinterpret_cast<decltype(table->field)>(dummy);
    PROHEN_MONO_EXTENSION_FIELDS(TEST_FIELD)
#undef TEST_FIELD
    if(partial_table) table->method_signature=nullptr;
    return 0;
}
static int sceKernelGetModuleList(OrbisKernelModule* out,size_t capacity,size_t* count) {
    assert(capacity==512);
    if(list_error)return -1;
    if(oversized){*count=513;return 0;}
    *count=2;out[0]=2;out[1]=8381;return 0;
}
static int sceKernelDlsym(int handle,const char* symbol,void** out) {
    if(handle==777) {
        assert(!strcmp(symbol,"ProHENGetMonoExtensions"));
        if(entry_missing||raw_only) return -2;
        *out=reinterpret_cast<void*>(provider);return 0;
    }
    if(module_missing || handle!=8381 || (missing&&!strcmp(missing,symbol)))return -3;
    *out=reinterpret_cast<void*>(dummy);return 0;
}
static int sys_dynlib_dlsym(int handle,const char* symbol,void* out) {
    assert(handle==777&&!strcmp(symbol,"ProHENGetMonoExtensions"));
    if(entry_missing) return -4;
    *static_cast<void**>(out)=reinterpret_cast<void*>(provider);return 0;
}
static int sceKernelLoadStartModule(const char* path,size_t size,const void* args,
                                   unsigned flags,const void* options,int* result) {
    assert(!strcmp(path,PRX_MONO_API_PATH)&&!size&&!args&&!flags&&!options);
    ++loads;*result=start_result;
    if(reenter) assert(!ProHENResolveMonoExtensions());
    return bridge_missing?-5:777;
}
static int sceKernelStopUnloadModule(int handle,size_t,const void*,unsigned,const void*,int*) {
    assert(handle==777);++unloads;return 0;
}
void ProHENStatus(const char* stage,const char* format,...) {
    char text[512];va_list args;va_start(args,format);vsnprintf(text,sizeof(text),format,args);va_end(args);
    notices.push_back(std::string(stage)+": "+text);
}
static void reset() {
    memset(&g_prohenMono,0,sizeof(g_prohenMono));
    g_optionalResolved=false;g_optionalBusy=0;g_bridgeAttempted=false;g_bridgeHandle=-1;
    list_error=oversized=module_missing=entry_missing=raw_only=partial_table=reenter=false;
    bridge_missing=true;missing=nullptr;provider_error=start_result=0;
    loads=unloads=provider_calls=0;notices.clear();
}
int main() {
    reset();assert(ProHENPanelAPIAvailable()&&ProHENMenuAPIAvailable()&&ProHENVersionAPIAvailable());assert(!loads);
    reset();missing="mono_class_get";assert(ProHENPanelAPIAvailable()&&ProHENVersionAPIAvailable());
    assert(!ProHENMenuAPIAvailable());assert(logged("missing optional export: mono_class_get")&&loads==1);
    reset();missing="mono_method_signature";assert(ProHENPanelAPIAvailable());assert(!ProHENMenuAPIAvailable()&&!ProHENVersionAPIAvailable());
    reset();missing="mono_field_get_value";assert(!ProHENPanelAPIAvailable()&&ProHENMenuAPIAvailable());assert(ProHENVersionAPIAvailable());
    reset();module_missing=true;assert(!ProHENResolveMonoExtensions());assert(logged("no Mono anchor"));module_missing=false;assert(ProHENResolveMonoExtensions());
    reset();list_error=true;assert(!ProHENResolveMonoExtensions());list_error=false;assert(ProHENResolveMonoExtensions());

    // Reproduce the supplied console log: no runtime lookup anchor, but normal
    // native imports can still bind the extra APIs through the companion.
    reset();module_missing=true;bridge_missing=false;reenter=true;
    assert(ProHENPanelAPIAvailable()&&ProHENMenuAPIAvailable()&&ProHENVersionAPIAvailable());
    assert(loads==1&&provider_calls==1&&!unloads&&g_bridgeHandle==777);
    assert(logged("no Mono anchor")&&logged("14 optional APIs bound"));
    assert(ProHENResolveMonoExtensions()&&loads==1);
    reset();list_error=true;bridge_missing=false;assert(ProHENMenuAPIAvailable());assert(logged("module list unavailable"));
    reset();oversized=true;bridge_missing=false;assert(ProHENMenuAPIAvailable());
    reset();module_missing=true;bridge_missing=false;raw_only=true;assert(ProHENMenuAPIAvailable());
    reset();missing="mono_class_get";bridge_missing=false;assert(ProHENMenuAPIAvailable());
    reset();module_missing=true;bridge_missing=false;entry_missing=true;
    assert(!ProHENPanelAPIAvailable()&&unloads==1&&logged("helper entry unavailable"));
    reset();module_missing=true;bridge_missing=false;provider_error=-9;
    assert(!ProHENVersionAPIAvailable()&&unloads==1&&logged("ABI or table rejected"));
    reset();module_missing=true;bridge_missing=false;partial_table=true;
    assert(!ProHENPanelAPIAvailable()&&!g_prohenMono.class_get_field_from_name&&unloads==1);
    reset();missing="mono_class_get";bridge_missing=false;partial_table=true;
    assert(ProHENPanelAPIAvailable()&&ProHENVersionAPIAvailable()&&!ProHENMenuAPIAvailable()&&unloads==1);
    reset();module_missing=true;bridge_missing=false;start_result=-1;
    assert(!ProHENPanelAPIAvailable()&&unloads==1&&!provider_calls);
    puts("PASS: missing Mono lookup anchor reproduces the console failure; optional native-link helper restores APIs, handles reentry and bad/missing helpers, preserves partial direct capabilities, and leaves core imports independent.");
}
