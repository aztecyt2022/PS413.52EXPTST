#include "../../common/mono_extensions.h"
#include "../../plugin_mono/source/mono.h"

// Module startup makes no Mono calls. The loader binds the imports, then
// this versioned entry point transfers their addresses to plugin_mono.
__attribute__((visibility("default")))
int ProHENGetMonoExtensions(uint32_t abi, size_t table_size,
                           struct ProHENMonoExtensions* table)
{
    if (abi != PROHEN_MONO_EXTENSIONS_ABI ||
        table_size != sizeof(*table) || !table)
        return -1;
#define PROHEN_EXPORT(field, symbol) table->field = symbol;
    PROHEN_MONO_EXTENSION_FIELDS(PROHEN_EXPORT)
#undef PROHEN_EXPORT
    return 0;
}
