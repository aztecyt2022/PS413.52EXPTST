#pragma once
#include <stdbool.h>
#include "../../common/mono_extensions.h"

// Optional APIs must not become mandatory PRX imports.
extern struct ProHENMonoExtensions g_prohenMono;
bool ProHENResolveMonoExtensions(void);
bool ProHENPanelAPIAvailable(void);
bool ProHENMenuAPIAvailable(void);
bool ProHENVersionAPIAvailable(void);

#define mono_class_get_field_from_name g_prohenMono.class_get_field_from_name
#define mono_field_get_value g_prohenMono.field_get_value
#define mono_class_get_methods g_prohenMono.class_get_methods
#define mono_method_get_name g_prohenMono.method_get_name
#define mono_method_signature g_prohenMono.method_signature
#define mono_signature_get_param_count g_prohenMono.signature_get_param_count
#define mono_signature_get_return_type g_prohenMono.signature_get_return_type
#define mono_type_get_type g_prohenMono.type_get_type
#define mono_method_get_flags g_prohenMono.method_get_flags
#define mono_image_get_table_info g_prohenMono.image_get_table_info
#define mono_table_info_get_rows g_prohenMono.table_info_get_rows
#define mono_class_get g_prohenMono.class_get
#define mono_class_get_name g_prohenMono.class_get_name
#define mono_class_get_namespace g_prohenMono.class_get_namespace
