/*
 * AZTEC System Overlay, an extension of Scene-Collective's MIT-licensed plugin_mono.
 * Native panel fields and Show/Hide/UITimer behavior are based on the published
 * Orbis-Toolbox DevkitPanel.cpp research by OSM-Made. No Orbis-Toolbox binary or
 * firmware-specific code offsets are copied.
 */
#include "system_overlay.h"
#include "../mono.h"
#include <string.h>
#include <wchar.h>
#include "../../../common/HDE/HDE64.h"
#include "../prohen_status.h"

#ifndef AZTEC_OVERLAY_TEST
#include <orbis/libkernel.h>
#include <unistd.h>
#include "../../../common/memory.h"
#include "../../../common/notify.h"
#include "../mono_optional.h"
#endif

static const char* kTopMenu = "Sce.Vsh.ShellUI.TopMenu";
static void* g_overlayArea;
static void* g_overlayPanelField;
static void* g_overlayTimerField;
static void* g_overlayCreate;
static void* g_overlayShow;
static void* g_overlayHide;
static void* g_overlayStart;
static void* g_overlayStop;
static bool g_overlayReady;
static bool g_overlayShown;
static bool g_overlayMenuReady;
static bool g_overlayInstallUnsafe;
static bool OverlayInitializePanel(void* app);

static bool OverlayInvoke(const void* method, const void* object)
{
    if (!method || !object)
        return false;
    const void* exception = NULL;
    mono_runtime_invoke(method, object, NULL, &exception);
    if (exception)
        printf("[AZTEC overlay] managed call failed\n");
    return !exception;
}

static void* OverlayMethod(void* klass, const char* name)
{
    return klass ? mono_class_get_method_from_name(klass, name, 0) : NULL;
}

static void* OverlayField(const void* object, const void* field)
{
    void* value = NULL;
    if (object && field)
        mono_field_get_value(object, field, &value);
    return value;
}

static void* OverlayAreaInstance(void)
{
    if (!g_overlayArea)
        return NULL;
    void* property = mono_class_get_property_from_name(g_overlayArea, "Instance");
    void* method = property ? mono_property_get_get_method(property) : NULL;
    if (!method)
        return NULL;
    const void* exception = NULL;
    void* instance = mono_runtime_invoke(method, NULL, NULL, &exception);
    return exception ? NULL : instance;
}

static bool OverlaySetVisible(bool visible)
{
    if (!g_overlayReady)
        return false;
    void* area = OverlayAreaInstance();
    if (!area)
        return false;
    void* panel = OverlayField(area, g_overlayPanelField);
    if (!panel && visible)
    {
        if (!OverlayInvoke(g_overlayCreate, area))
            return false;
        panel = OverlayField(area, g_overlayPanelField);
    }
    void* timer = OverlayField(area, g_overlayTimerField);
    if (!visible && !panel)
    {
        g_overlayShown = false;
        return !timer || OverlayInvoke(g_overlayStop, timer);
    }
    if (!panel)
        return false;
    if (visible)
    {
        // Creation may have started the native timer already. Start is idempotent.
        if (!timer || !OverlayInvoke(g_overlayShow, panel) || !OverlayInvoke(g_overlayStart, timer))
        {
            OverlayInvoke(g_overlayHide, panel);
            if (timer) OverlayInvoke(g_overlayStop, timer);
            g_overlayShown = false;
            return false;
        }
    }
    else
    {
        if (timer && !OverlayInvoke(g_overlayStop, timer))
            return false;
        if (!OverlayInvoke(g_overlayHide, panel))
            return false;
    }
    g_overlayShown = visible;
    return true;
}

bool SystemOverlayReady(void) { return g_overlayReady; }
bool SystemOverlayMenuReady(void) { return g_overlayMenuReady; }

bool SystemOverlayToggle(void)
{
    if (!g_overlayReady && App_Exe)
        OverlayInitializePanel(App_Exe);
    if (!OverlaySetVisible(!g_overlayShown))
    {
        ProHENStatus("overlay", "local toggle unavailable; no Friends or PSN launch was requested");
        Notify("", "System Overlay unavailable. See /data/hen/prohen-status.log.");
        return false;
    }
    return true;
}

void SystemOverlayOnBoot(void)
{
    if (g_overlayReady && !OverlaySetVisible(false))
        printf("[AZTEC overlay] panel reset deferred until first selection\n");
}

bool SystemOverlayIsTitle(const wchar_t* key)
{
    // TopMenuPlugin alone calls this. Keep friend requests and notifications intact.
    if (!g_overlayMenuReady || !key)
        return false;
    return wcscmp(key, L"msg_friend") == 0 || wcscmp(key, L"msg_friends") == 0 ||
           wcscmp(key, L"msg_friend_long") == 0 || wcscmp(key, L"msg_friends_long") == 0 ||
           wcscmp(key, L"msg_friend_title") == 0 || wcscmp(key, L"msg_friends_title") == 0;
}

static void OverlayFriendSelected(void* instance)
{
    (void)instance;
    ProHENStatus("overlay", "Friends selection intercepted; using local overlay action");
    SystemOverlayToggle();
}

struct OverlayFriendMethods
{
    void* select;
    void* launch;
    const char* klass;
};

static bool OverlayFriendSignature(void* method)
{
    const void* signature = mono_method_signature(method);
    const void* result = signature ? mono_signature_get_return_type(signature) : NULL;
    uint32_t flags = mono_method_get_flags(method, NULL);
    return signature && result && !(flags & (0x10u | 0x400u)) &&
           mono_signature_get_param_count(signature) == 0 && mono_type_get_type(result) == 0x01;
}

static bool OverlayFindFriendMethods(void* app, struct OverlayFriendMethods* selected)
{
    const void* table = mono_image_get_table_info(app, 2);
    const int count = table ? mono_table_info_get_rows(table) : 0;
    if (count <= 0 || count > 50000) return false;
    unsigned traced_classes = 0;
    for (int row = 1; row <= count; ++row)
    {
        void* klass = mono_class_get(app, 0x02000000u | (uint32_t)row);
        if (!klass) continue;
        const char* ns = mono_class_get_namespace(klass);
        const char* name = mono_class_get_name(klass);
        if (!ns || !name || strcmp(ns, kTopMenu)) continue;
        bool eligible = !strcmp(name, "SystemAreaIconFriend") || !strcmp(name, "SystemAreaIconFriends");
        bool trace = !strncmp(name, "SystemAreaIcon", 14) && strstr(name, "Friend") && traced_classes < 4;
        if (!eligible && !trace) continue;
        if (trace)
        {
            ++traced_classes;
            ProHENStatus("overlay", "Friends metadata class: %s", name);
        }
        struct OverlayFriendMethods candidate = {NULL, NULL, name};
        unsigned traced_methods = 0;
        void* iterator = NULL;
        void* method;
        while ((method = mono_class_get_methods(klass, &iterator)))
        {
            const char* method_name = mono_method_get_name(method);
            if (!method_name) continue;
            if (trace && traced_methods++ < 6)
            {
                const void* signature = mono_method_signature(method);
                const void* result = signature ? mono_signature_get_return_type(signature) : NULL;
                ProHENStatus("overlay", "Friends method %s.%s args=%u flags=0x%x return=0x%x",
                             name, method_name, signature ? mono_signature_get_param_count(signature) : 0xffffffffu,
                             mono_method_get_flags(method, NULL), result ? mono_type_get_type(result) : 0);
            }
            if (!eligible) continue; // Unknown classes are reported, never patched.
            void** slot = !strcmp(method_name, "IconSelect") ? &candidate.select :
                          !strcmp(method_name, "LaunchPlugin") ? &candidate.launch : NULL;
            if (!slot || !OverlayFriendSignature(method)) continue;
            if (*slot) return false;
            *slot = method;
        }
        if (!candidate.select && !candidate.launch) continue;
        if (selected->select || selected->launch) return false;
        *selected = candidate;
    }
    return selected->select || selected->launch;
}

static bool OverlayInitializePanel(void* app)
{
    if (g_overlayReady)
        return true;
    OrbisKernelSwVersion version = {};
    version.Size = sizeof(version);
    if (sceKernelGetSystemSwVersion(&version) != 0 || (version.Version & 0xffff0000u) != 0x13520000u)
        return false;
    if (!app || !Root_Domain)
        return false;
#ifndef AZTEC_OVERLAY_TEST
    if (!ProHENPanelAPIAvailable())
    {
        ProHENStatus("overlay", "panel field APIs unavailable; menu remains usable");
        return false;
    }
#endif
    g_overlayArea = mono_class_from_name(app, kTopMenu, "AreaManager");
    if (!g_overlayArea)
        return false;
    g_overlayPanelField = mono_class_get_field_from_name(g_overlayArea, "m_devKitPanel");
    g_overlayTimerField = mono_class_get_field_from_name(g_overlayArea, "m_updatePanelTimer");
    g_overlayCreate = OverlayMethod(g_overlayArea, "createDevKitPanel");

    const char* sandbox = sceKernelGetFsSandboxRandomWord();
    if (!sandbox || !sandbox[0])
        return false;
    char path[260];
    g_overlayShow = g_overlayHide = g_overlayStart = g_overlayStop = NULL;
    const char* assemblies[] = {"Sce.PlayStation.PUI.dll", "Sce.PlayStation.HighLevel.UI2.dll"};
    const char* namespaces[] = {"Sce.PlayStation.PUI", "Sce.PlayStation.HighLevel.UI2"};
    for (size_t i = 0; i < 2; ++i)
    {
        snprintf(path, sizeof(path), "/%s/common/lib/%s", sandbox, assemblies[i]);
        void* ui = mono_get_image(path);
        if (!ui) continue;
        void* node = mono_class_from_name(ui, namespaces[i], "UINode");
        void* timer = mono_class_from_name(ui, namespaces[i], "UITimer");
        g_overlayShow = OverlayMethod(node, "Show");
        g_overlayHide = OverlayMethod(node, "Hide");
        g_overlayStart = OverlayMethod(timer, "Start");
        g_overlayStop = OverlayMethod(timer, "Stop");
        if (g_overlayShow && g_overlayHide && g_overlayStart && g_overlayStop) break;
    }
    if (!g_overlayCreate || !g_overlayPanelField || !g_overlayTimerField ||
        !g_overlayShow || !g_overlayHide || !g_overlayStart || !g_overlayStop ||
        !mono_class_get_property_from_name(g_overlayArea, "Instance"))
    {
#ifndef AZTEC_OVERLAY_TEST
        ProHENStatus("overlay", "binding missing: panel=%d timer=%d create=%d show=%d hide=%d start=%d stop=%d",
                     !!g_overlayPanelField, !!g_overlayTimerField, !!g_overlayCreate,
                     !!g_overlayShow, !!g_overlayHide, !!g_overlayStart, !!g_overlayStop);
#endif
        return false;
    }
    g_overlayReady = true;
    g_overlayShown = false;
#ifndef AZTEC_OVERLAY_TEST
    ProHENStatus("overlay", "panel controls ready; Friends hook is a separate step");
#endif
    return true;
}

static bool OverlaySafeHookTarget(uintptr_t target, uintptr_t text, size_t size)
{
    if (target < text || target - text > size - 32) return false;
    size_t covered = 0;
    while (covered < 14)
    {
        hde64s instruction = {};
        unsigned int length = hde64_disasm((const void*)(target + covered), &instruction);
        if (!length || (instruction.flags & F_ERROR) || instruction.opcode == 0xc3 ||
            instruction.opcode == 0xc2 || instruction.opcode == 0xcc ||
            instruction.opcode == 0xe9 || instruction.opcode == 0xeb ||
            (instruction.opcode == 0xff && instruction.modrm_reg == 4)) return false;
        covered += length;
    }
    return true;
}

bool SystemOverlayInstall(void* app, uintptr_t text, size_t text_size)
{
    OrbisKernelSwVersion firmware = {};
    firmware.Size = sizeof(firmware);
    if (sceKernelGetSystemSwVersion(&firmware) != 0 ||
        (firmware.Version & 0xffff0000u) != 0x13520000u || !app || !Root_Domain) return false;
    // Panel binding is independent: a missing renderer must not send the local
    // shortcut through the normal Friends account/sign-in action.
    OverlayInitializePanel(app);
    if (g_overlayMenuReady) return true;
    if (g_overlayInstallUnsafe || !text || text_size < 32) return false;
#ifndef AZTEC_OVERLAY_TEST
    if (!ProHENMenuAPIAvailable())
    {
        ProHENStatus("overlay", "Friends dispatch metadata unavailable; shortcut not installed; use PROHEN Settings");
        return false;
    }
#endif
    struct OverlayFriendMethods methods = {NULL, NULL, NULL};
    if (!OverlayFindFriendMethods(app, &methods))
    {
        ProHENStatus("overlay", "Friends selection/launch metadata missing or ambiguous; shortcut not installed");
        return false;
    }
    if (!methods.select)
    {
        // The reported PSN path can run before LaunchPlugin. Do not label a
        // late-only hook as a working local shortcut.
        ProHENStatus("overlay", "Friends IconSelect unavailable; late LaunchPlugin left unchanged; use PROHEN Settings");
        Notify("", "Friends shortcut unavailable. Use PROHEN Settings > System Overlay.");
        return false;
    }
    // IconSelect is an earlier selection entry point in the SystemAreaIcon
    // contract. Cover direct LaunchPlugin callers too. Only declared methods
    // on a recognized Friends class qualify; never patch the shared base class.
    struct Patch { uintptr_t target; uint8_t original[14]; } patches[2];
    size_t count = 0;
    void* candidates[] = {methods.select, methods.launch};
    for (size_t i = 0; i < 2; ++i)
    {
        if (!candidates[i]) continue;
        uintptr_t target = (uintptr_t)mono_aot_get_method(Root_Domain, candidates[i]);
        if (count && patches[0].target == target) continue;
        if (!OverlaySafeHookTarget(target, text, text_size))
        {
            ProHENStatus("overlay", "Friends %s native target rejected; no shortcut writes",
                         i ? "LaunchPlugin" : "IconSelect");
            return false;
        }
        if (count && (target > patches[0].target ? target - patches[0].target : patches[0].target - target) < 14)
        {
            ProHENStatus("overlay", "Friends native methods overlap; no shortcut writes");
            return false;
        }
        patches[count].target = target;
        memcpy(patches[count].original, (const void*)target, sizeof(patches[count].original));
        ++count;
    }
    if (!count) return false;
    uint8_t patch[14] = {0xff, 0x25, 0, 0, 0, 0};
    uintptr_t hook = (uintptr_t)OverlayFriendSelected;
    memcpy(patch + 6, &hook, sizeof(hook));
    size_t attempted = 0;
    bool installed = true;
    for (size_t i = 0; i < count; ++i)
    {
        ++attempted;
        sys_proc_rw(getpid(), patches[i].target, patch, sizeof(patch), 1);
        if (memcmp((const void*)patches[i].target, patch, sizeof(patch)))
        { installed = false; break; }
    }
    installed = installed && RestoreFriendPanelName();
    if (!installed)
    {
        for (size_t i = 0; i < attempted; ++i)
        {
            sys_proc_rw(getpid(), patches[i].target, patches[i].original, sizeof(patches[i].original), 1);
            if (memcmp((const void*)patches[i].target, patches[i].original, sizeof(patches[i].original)))
                g_overlayInstallUnsafe = true;
        }
        ProHENStatus("overlay", "Friends hook verification failed; rollback=%s",
                     g_overlayInstallUnsafe ? "failed; reboot required" : "verified");
        if (g_overlayInstallUnsafe)
            Notify("", "PROHEN: Friends hook restoration failed. Restart PS4 before using the menu.");
        return false;
    }
    g_overlayMenuReady = true;
    g_overlayShown = false;
    ProHENStatus("overlay", "Friends %s hooks verified; panel=%s",
                 methods.launch ? "IconSelect + LaunchPlugin" : "IconSelect",
                 g_overlayReady ? "ready" : "pending; selection stays local");
    return true;
}
