#include "mono_optional.h"
#include "prohen_status.h"
#include <stddef.h>
#include <string.h>
#ifndef PROHEN_OPTIONAL_TEST
#include <orbis/libkernel.h>
#include "../../common/path.h"
#include "../../common/syscall.h"
#endif

struct ProHENMonoExtensions g_prohenMono;
static bool g_optionalResolved;
static int g_optionalBusy;
static bool g_bridgeAttempted;
static int g_bridgeHandle = -1;

static bool ProHENCompleteMonoTable(const struct ProHENMonoExtensions* table)
{
#define PROHEN_HAS(field, symbol) if (!table->field) return false;
    PROHEN_MONO_EXTENSION_FIELDS(PROHEN_HAS)
#undef PROHEN_HAS
    return true;
}

static bool ProHENLoadMonoBridge(void)
{
    if (g_bridgeAttempted) return false;
    g_bridgeAttempted = true;
    int result = 0;
    int module = sceKernelLoadStartModule(PRX_MONO_API_PATH, 0, NULL, 0, NULL, &result);
    if (module <= 0 || result < 0)
    {
        ProHENStatus("mono", "optional API helper failed: handle=0x%08x result=0x%08x; install matching plugin_mono_api.prx",
                     module, result);
        if (module > 0) sceKernelStopUnloadModule(module, 0, NULL, 0, NULL, NULL);
        return false;
    }
    void* symbol = NULL;
    int lookup = sceKernelDlsym(module, "ProHENGetMonoExtensions", &symbol);
    if (lookup != 0 || !symbol)
    {
        symbol = NULL;
        lookup = sys_dynlib_dlsym(module, "ProHENGetMonoExtensions", &symbol);
    }
    if (lookup != 0 || !symbol)
    {
        ProHENStatus("mono", "optional API helper entry unavailable: 0x%08x", lookup);
        sceKernelStopUnloadModule(module, 0, NULL, 0, NULL, NULL);
        return false;
    }
    ProHENMonoExtensionProvider provider = NULL;
    memcpy(&provider, &symbol, sizeof(provider));
    struct ProHENMonoExtensions table;
    memset(&table, 0, sizeof(table));
    int status = provider(PROHEN_MONO_EXTENSIONS_ABI, sizeof(table), &table);
    if (status != 0 || !ProHENCompleteMonoTable(&table))
    {
        ProHENStatus("mono", "optional API helper ABI or table rejected: 0x%08x", status);
        sceKernelStopUnloadModule(module, 0, NULL, 0, NULL, NULL);
        return false;
    }
    // Keep the helper mapped: these pointers refer to its native dependencies.
    g_bridgeHandle = module;
    g_prohenMono = table;
    ProHENStatus("mono", "14 optional APIs bound by native-link helper, handle %d", module);
    return true;
}

bool ProHENResolveMonoExtensions(void)
{
    if (__atomic_load_n(&g_optionalResolved, __ATOMIC_ACQUIRE)) return true;
    // Loading the companion can re-enter the module-load callback.
    if (__atomic_exchange_n(&g_optionalBusy, 1, __ATOMIC_ACQUIRE))
        return false;
    OrbisKernelModule handles[512];
    size_t available = 0;
    int list = sceKernelGetModuleList(handles, 512, &available);
    int module = -1;
    int anchor_error = 0;
    if (list == 0 && available <= 512)
    {
        for (size_t i = 0; i < available; ++i)
        {
            void* anchor = NULL;
            anchor_error = sceKernelDlsym(handles[i], "mono_get_root_domain", &anchor);
            if (anchor_error == 0 && anchor)
            { module = handles[i]; break; }
        }
        if (module < 0)
            ProHENStatus("mono", "runtime export lookup found no Mono anchor in %zu modules; last=0x%08x; trying native-link helper",
                         available, anchor_error);
    }
    else
        ProHENStatus("mono", "module list unavailable: result=0x%08x count=%zu; trying native-link helper", list, available);

    if (module >= 0)
    {
#define PROHEN_RESOLVE(field, name) do { \
        void* symbol = NULL; \
        if (sceKernelDlsym(module, #name, &symbol) == 0 && symbol) \
            memcpy(&g_prohenMono.field, &symbol, sizeof(symbol)); \
    } while (0);
        PROHEN_MONO_EXTENSION_FIELDS(PROHEN_RESOLVE)
#undef PROHEN_RESOLVE
    }
    if (!ProHENCompleteMonoTable(&g_prohenMono))
        ProHENLoadMonoBridge();

    if (module >= 0 || g_bridgeHandle > 0)
    {
#define PROHEN_MISSING(field, name) \
        if (!g_prohenMono.field) ProHENStatus("mono", "missing optional export: " #name);
        PROHEN_MONO_EXTENSION_FIELDS(PROHEN_MISSING)
#undef PROHEN_MISSING
        __atomic_store_n(&g_optionalResolved, true, __ATOMIC_RELEASE);
    }
    __atomic_store_n(&g_optionalBusy, 0, __ATOMIC_RELEASE);
    return __atomic_load_n(&g_optionalResolved, __ATOMIC_ACQUIRE);
}

bool ProHENPanelAPIAvailable(void)
{
    return ProHENResolveMonoExtensions() && g_prohenMono.class_get_field_from_name && g_prohenMono.field_get_value;
}

bool ProHENMenuAPIAvailable(void)
{
    return ProHENPanelAPIAvailable() && ProHENCompleteMonoTable(&g_prohenMono);
}

bool ProHENVersionAPIAvailable(void)
{
    return ProHENResolveMonoExtensions() && g_prohenMono.method_signature && g_prohenMono.signature_get_param_count &&
           g_prohenMono.signature_get_return_type && g_prohenMono.type_get_type && g_prohenMono.method_get_flags;
}
