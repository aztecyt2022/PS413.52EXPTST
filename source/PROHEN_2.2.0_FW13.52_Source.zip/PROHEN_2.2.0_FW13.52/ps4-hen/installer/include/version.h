#ifndef VERSION_H_
#define VERSION_H_

#include "../../../prohen_version.h"

#define VERSION PROHEN_VERSION
#define MIN_FW 474
#define MAX_FW 1352

#endif
