PROHEN 2.2.0 BETA - PS4 firmware 13.52 - custom build 2

CHANGES
The PS4 home-menu HEN icon is titled PROHEN. The Settings entry and page are
named PROHEN Settings. Settings > System > System Information displays the
existing System Software value followed by " | PROHEN 2.2.0 BETA". For example:

    13.52 | PROHEN 2.2.0 BETA

The display addition is applied after ShellUI boots and when Settings starts.
It reads and updates SystemSoftwareVersionInfo.DisplayVersion using managed
Mono properties. It preserves the native firmware text and uses no new code
hooks or offsets for this addition. It leaves the original value alone when
firmware/API/metadata checks fail, contains managed exceptions, and attempts
to restore the original value if setter verification fails. It does not detect
arbitrary third-party jailbreaks; it identifies this bundled PROHEN payload.
The kernel firmware version and compatibility checks are unchanged.

The installer writes the PROHEN identity to /data/hen/version.txt and uses
PROHEN in its welcome/restart notifications. Installer and plugin share
prohen_version.h so their product name and version agree. Existing filenames,
configuration paths, plugin ABI and saved settings remain compatible.

EXISTING SYSTEM OVERLAY
The former Friends position toggles the PS4's native system-information/devkit
panel. Recognized Friends title keys become System Overlay. The panel starts
hidden; its timer starts when shown and stops when hidden. PROHEN Settings
has a second toggle. This is a home-screen panel, not an in-game overlay.
Messages and other normally hidden entries remain hidden. No synthetic
hardware readings replace native data.

TEST STATUS
This is a compiled test build. Its actual behavior on PS4 firmware 13.52 has
not been verified on a physical console. Native-API mocks verify property
updates, menu control flow, idempotence, firmware guards, missing metadata,
managed errors, allocation failures, and rollback behavior. These tests do
not establish physical-console compatibility. The new display addition and
existing Friends hook are restricted to firmware 13.52.

USING THIS BUILD
binaries/prohen.bin is the complete payload to give your existing compatible
13.52 exploit loader. It includes the plugins. binaries/plugin_mono.prx is the
matching ShellUI plugin, normally installed by the complete payload as
/data/hen/plugin_shellui.prx. Use enable_plugins=1 and upload_prx=1 in your
existing hen.ini, then reboot before loading this build. The existing guard
prevents replacing an active HEN in the same boot. This build preserves saved
configuration choices rather than forcing those settings.

The accompanying PROHEN GitHub Pages ZIP loads this build by default. It
retains the password prompt, PS4 13.52 check, manual load, and optional ten
second automatic load. Its original HEN option loads the unmodified upstream
payload. The previously published live host has not been changed.

RECOVERY AND ROLLBACK
Reboot and load the original HEN payload with upload_prx=1 to restore its
bundled plugins. If ShellUI cannot start, remove or replace
/data/hen/plugin_shellui.prx from an existing recovery environment.

BUILD
The snapshot includes ps4-hen, ps4-hen-plugins and the matching payload SDK.
Install GCC/G++, GNU binutils/make, xxd, Clang 18 and LLD 18. Obtain the OpenOrbis
headers/stubs and create-fself utility from the official v0.5.3
toolchain-llvm-18.2 release, then set OO_PS4_TOOLCHAIN to its
OpenOrbis/PS4Toolchain directory. Run bash build-test.sh from this directory.
The build does not install packages, contact a console, or publish anything.

The kernel source, firmware offsets and default hen.ini are unchanged from
the pinned HEN baseline. Installer changes are limited to branding and version
metadata. SOURCE_REVISIONS.json records upstream revisions. The display
property API is documented in OSM-Made's Orbis-Toolbox UI_Utilities.cpp.

LICENSES AND CREDITS
This is a custom fork of Scene-Collective HEN 2.2.0 BETA, not an official HEN
release. Credits: Scene-Collective, illusiony, Al-Azif, raw13g, OSM-Made and the
original HEN contributors. Keep bundled LICENSE files and notices. Native
panel API research: OSM-Made's Orbis-Toolbox DevkitPanel.cpp. The plugin
additions use the plugin project's MIT terms. Server components and libjbc
retain their own GPL notices. No Sony firmware executable or assembly is
included. Upstream source URLs and revisions are recorded with the source.
