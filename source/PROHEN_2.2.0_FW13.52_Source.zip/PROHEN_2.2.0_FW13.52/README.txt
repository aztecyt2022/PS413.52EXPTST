PROHEN 2.2.0 BETA - PS4 13.52 - REPAIR CANDIDATE 3

This candidate addresses the reported missing icon and non-working System
Overlay. It is not confirmed working on a physical PS4. This source bundle
accompanies the owner-authorized GitHub Pages publication of build 3.

REPAIRS
- Preserve the Friends slot before ShellUI builds its menu, rather than hide
  it first and attempt to restore its serialized name after initialization.
- Keep the offline PS Plus entry used for the PROHEN menu action.
- Initialize as soon as both the Mono domain and app image are available.
  Retry delayed critical metadata even when the app image already exists.
  Prevent recursive/concurrent initialization and repeated partial patches.
- Resolve 14 optional Mono APIs at runtime. An unavailable extra API can no
  longer prevent the base menu plugin from loading through a mandatory import.
- Keep the panel controls available from PROHEN Settings independently of the
  Friends shortcut. Change the Friends title only after its hook succeeds.
- Try the alternate UI assembly when the first assembly lacks the methods,
  and clear stale bindings between unsuccessful attempts.
- Preflight critical menu metadata and verify action, title, icon and Settings
  hook writes before reporting successful setup. Preserve instruction guards.
- Bound notification text/icon copies and save a bounded setup-status log.

FILES AND CONSOLE CHECK
binaries/prohen.bin is the complete payload with matching bundled plugins.
binaries/plugin_mono.prx is its ShellUI plugin. The actual installed path is
/data/hen/plugin_mono.prx. Earlier notes naming plugin_shellui.prx were wrong.
Existing configuration paths and plugin ABI remain compatible.

1. Reboot before loading this build. An existing HEN session prevents a second
   payload from replacing the current one in the same boot.
2. The saved /data/hen/hen.ini or USB override needs enable_plugins=1 and
   upload_prx=1. This candidate reports disabled settings without overriding
   them. Saved settings can otherwise leave the old plugin installed.
3. Expect the notification "PROHEN build 3: ShellUI plugin loaded." Press Up
   into the home screen's top function row and check the PROHEN shortcut at
   the PS Plus position. No game/app tile is installed by this payload.
4. In PROHEN Settings, select System Overlay, then return to the home screen
   to view the native information panel. A working Friends shortcut can also
   toggle it directly. Select again to hide the panel.

If either feature still fails, provide /data/hen/prohen-status.log and report
whether PROHEN Settings exists in Settings. The log records plugin startup,
missing exports, delayed methods, failed native writes and panel bindings.
No plugin notification/log means module loading itself needs investigation.
The code cannot establish that failure from a desktop-only build.

VERSION DISPLAY
The menu title remains PROHEN and the Settings page PROHEN Settings. The
System Information display preserves its native firmware text and appends
" | PROHEN 2.2.0 BETA" when supported. Installer and plugin share
prohen_version.h. The native panel and version additions require firmware
13.52; no firmware offsets were added. The renderer is a home-screen panel,
not an in-game overlay. The Messages entry remains hidden.

ROLLBACK
Reboot, then load the original HEN payload with upload_prx=1 to restore its
bundled plugins. If ShellUI cannot start, remove or replace
/data/hen/plugin_mono.prx from an existing recovery environment.

BUILD AND VERIFICATION
Install GCC/G++, GNU binutils/make, Python 3, xxd, Clang 18 and LLD 18. Obtain
the OpenOrbis headers/stubs and create-fself utility from the official v0.5.3
toolchain-llvm-18.2 release. Set OO_PS4_TOOLCHAIN to OpenOrbis/PS4Toolchain and
run bash build-test.sh here. The SDK and native component sources are included.
This script does not install packages, contact a console, or publish anything.

Tests exercise panel toggling, timer cleanup, missing/ambiguous Friends hooks,
UI metadata fallback, managed failures, version preservation, delayed startup,
re-entry, optional export resolution, and the mandatory-import boundary. They
do not prove real-console menu visibility, input behavior or compatibility.
The kernel sources, firmware offsets and default hen.ini are unchanged from
the pinned baseline. The installer only changes branding/version metadata and
reports disabled plugin settings. SOURCE_REVISIONS.json lists upstream pins.

CREDITS AND LICENSES
This is a custom fork of Scene-Collective HEN 2.2.0 BETA, not an official HEN
release. Credits: Scene-Collective, illusiony, Al-Azif, raw13g, OSM-Made and the
original HEN contributors. OSM-Made's Orbis-Toolbox documents the native panel
and DisplayVersion API. Keep all bundled LICENSE files and notices. Plugin
additions use the plugin project's MIT terms; server components and libjbc
retain their GPL notices. No Sony firmware executable or managed assembly is
included. Unchanged upstream source is included for rebuilding.
