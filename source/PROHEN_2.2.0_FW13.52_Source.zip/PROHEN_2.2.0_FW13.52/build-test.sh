#!/usr/bin/env bash
set -euo pipefail
task_root=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
: "${OO_PS4_TOOLCHAIN:?Set OO_PS4_TOOLCHAIN to the OpenOrbis PS4Toolchain directory}"
export PS4SDK="$task_root/ps4-payload-sdk"
plugins_root="$task_root/ps4-hen-plugins"
payload_root="$task_root/ps4-hen"
mkdir -p "$task_root/binaries" "$task_root/verification"

cat > "$plugins_root/common/git_ver.h" <<'BUILD'
#define GIT_COMMIT "49534177d69d17609bcc09cd185c88df42fed8b5 + PROHEN custom build 2"
#define GIT_VER "PROHEN 2.2.0 BETA custom build 2"
#define GIT_NUM 2
#define GIT_NUM_STR "prohen2"
#define BUILD_DATE "2026-10-21"
BUILD

bash "$plugins_root/int3.sh" 4096 > "$plugins_root/common/cave.inc.c"
for plugin_dir in plugin_bootloader plugin_loader plugin_mono plugin_server plugin_shellcore; do
    make -C "$plugins_root/$plugin_dir" -o build-info AR=ar clean all
done

make -C "$PS4SDK/libPS4" clean
make -C "$PS4SDK/libPS4"
make -C "$payload_root/kpayload" clean all
mkdir -p "$payload_root/tmp"
cp "$plugins_root/bin/plugins/prx/"*.prx "$payload_root/tmp/"
(
    cd "$payload_root/tmp"
    for prx in *.prx; do
        xxd -i "$prx" | sed 's/^unsigned /static const unsigned /' > "../installer/source/$prx.inc.c"
    done
    cd ..
    xxd -i hen.ini | sed 's/^unsigned /static const unsigned /' > installer/source/hen.ini.inc.c
)
make -C "$payload_root/installer" clean all
cp "$payload_root/installer/installer.bin" "$task_root/binaries/prohen.bin"
cp "$plugins_root/bin/plugins/prx/plugin_mono.prx" "$task_root/binaries/plugin_mono.prx"
g++ -std=c++17 -Wall -Wextra "$plugins_root/tests/system_overlay_test.cc" -o "$task_root/verification/overlay-tests"
"$task_root/verification/overlay-tests" | tee "$task_root/verification/overlay-tests.txt"
g++ -std=c++17 -Wall -Wextra "$plugins_root/tests/prohen_info_test.cc" -o "$task_root/verification/prohen-info-tests"
"$task_root/verification/prohen-info-tests" | tee "$task_root/verification/prohen-info-tests.txt"
(
    cd "$task_root/binaries"
    sha256sum prohen.bin plugin_mono.prx > SHA256SUMS.txt
)
echo "Built binaries/prohen.bin (console testing required)"
