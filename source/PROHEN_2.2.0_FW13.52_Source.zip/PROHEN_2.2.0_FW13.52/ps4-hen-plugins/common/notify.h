#pragma once

#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <orbis/libkernel.h>

#define TEX_ICON_SYSTEM "cxml://psnotification/tex_icon_system"

// For formatted strings
static void Notify(const char* IconUri, const char* FMT, ...)
{
    OrbisNotificationRequest Buffer = {};
    va_list args;
    va_start(args, FMT);
    vsnprintf(Buffer.message, sizeof(Buffer.message), FMT, args);
    const size_t len = strlen(Buffer.message);
    const size_t len2 = len ? len - 1 : 0;
    if (len > 0 && Buffer.message[len2] == '\n')
    {
        Buffer.message[len2] = 0;
    }
    va_end(args);
    printf("Notify message:\n%s\n", Buffer.message);
    Buffer.type = NotificationRequest;
    Buffer.unk3 = 0;
    Buffer.useIconImageUri = 1;
    Buffer.targetId = -1;
    if (IconUri && *IconUri)
    {
        snprintf(Buffer.iconUri, sizeof(Buffer.iconUri), "%s", IconUri);
    }
    else
    {
        snprintf(Buffer.iconUri, sizeof(Buffer.iconUri), "%s", TEX_ICON_SYSTEM);
    }
    sceKernelSendNotificationRequest(0, &Buffer, sizeof(Buffer), 0);
}

