#include "shellui_startup.h"
#include "mono.h"
#include "prohen_status.h"

extern bool UploadOnBranch(void* app, int app_handle);
extern void UploadNewPkgInstallerPath(void* app, int app_handle);

static int g_startupBusy;
static bool g_startupReady;

bool ProHENTryInitializeShellUI(int app_handle)
{
    if (__atomic_load_n(&g_startupReady, __ATOMIC_ACQUIRE))
        return true;
    if (app_handle <= 0 || __atomic_exchange_n(&g_startupBusy, 1, __ATOMIC_ACQUIRE))
        return false;
    if (!Root_Domain)
        Root_Domain = mono_get_root_domain();
    if (Root_Domain && !App_Exe)
        App_Exe = mono_get_image("/app0/psm/Application/app.exe");
    if (Root_Domain && App_Exe && UploadOnBranch(App_Exe, app_handle))
    {
        UploadNewPkgInstallerPath(App_Exe, app_handle);
        __atomic_store_n(&g_startupReady, true, __ATOMIC_RELEASE);
        ProHENStatus("startup", "home-menu hooks installed");
    }
    else if (!Root_Domain || !App_Exe)
        ProHENStatus("startup", "waiting for Mono domain or ShellUI assembly");
    __atomic_store_n(&g_startupBusy, 0, __ATOMIC_RELEASE);
    return __atomic_load_n(&g_startupReady, __ATOMIC_ACQUIRE);
}
