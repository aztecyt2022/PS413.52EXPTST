#include "mono_optional.h"
#include "prohen_status.h"
#include <stddef.h>
#include <string.h>
#ifndef PROHEN_OPTIONAL_TEST
#include <orbis/libkernel.h>
#endif

struct ProHENMonoExtensions g_prohenMono;
static bool g_optionalResolved;

bool ProHENResolveMonoExtensions(void)
{
    if (g_optionalResolved) return true;
    OrbisKernelModule handles[512];
    size_t available = 0;
    if (sceKernelGetModuleList(handles, 512, &available) != 0 || available > 512)
    {
        ProHENStatus("mono", "loaded module list unavailable or too large");
        return false;
    }
    int module = -1;
    for (size_t i = 0; i < available; ++i)
    {
        void* anchor = NULL;
        if (sceKernelDlsym(handles[i], "mono_get_root_domain", &anchor) == 0 && anchor)
        { module = handles[i]; break; }
    }
    if (module < 0) return false;
    void* symbol = NULL;
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_class_get_field_from_name", &symbol) == 0)
        memcpy(&g_prohenMono.class_get_field_from_name, &symbol, sizeof(symbol));
    if (!g_prohenMono.class_get_field_from_name) ProHENStatus("mono", "missing optional export: mono_class_get_field_from_name");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_field_get_value", &symbol) == 0)
        memcpy(&g_prohenMono.field_get_value, &symbol, sizeof(symbol));
    if (!g_prohenMono.field_get_value) ProHENStatus("mono", "missing optional export: mono_field_get_value");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_class_get_methods", &symbol) == 0)
        memcpy(&g_prohenMono.class_get_methods, &symbol, sizeof(symbol));
    if (!g_prohenMono.class_get_methods) ProHENStatus("mono", "missing optional export: mono_class_get_methods");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_method_get_name", &symbol) == 0)
        memcpy(&g_prohenMono.method_get_name, &symbol, sizeof(symbol));
    if (!g_prohenMono.method_get_name) ProHENStatus("mono", "missing optional export: mono_method_get_name");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_method_signature", &symbol) == 0)
        memcpy(&g_prohenMono.method_signature, &symbol, sizeof(symbol));
    if (!g_prohenMono.method_signature) ProHENStatus("mono", "missing optional export: mono_method_signature");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_signature_get_param_count", &symbol) == 0)
        memcpy(&g_prohenMono.signature_get_param_count, &symbol, sizeof(symbol));
    if (!g_prohenMono.signature_get_param_count) ProHENStatus("mono", "missing optional export: mono_signature_get_param_count");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_signature_get_return_type", &symbol) == 0)
        memcpy(&g_prohenMono.signature_get_return_type, &symbol, sizeof(symbol));
    if (!g_prohenMono.signature_get_return_type) ProHENStatus("mono", "missing optional export: mono_signature_get_return_type");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_type_get_type", &symbol) == 0)
        memcpy(&g_prohenMono.type_get_type, &symbol, sizeof(symbol));
    if (!g_prohenMono.type_get_type) ProHENStatus("mono", "missing optional export: mono_type_get_type");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_method_get_flags", &symbol) == 0)
        memcpy(&g_prohenMono.method_get_flags, &symbol, sizeof(symbol));
    if (!g_prohenMono.method_get_flags) ProHENStatus("mono", "missing optional export: mono_method_get_flags");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_image_get_table_info", &symbol) == 0)
        memcpy(&g_prohenMono.image_get_table_info, &symbol, sizeof(symbol));
    if (!g_prohenMono.image_get_table_info) ProHENStatus("mono", "missing optional export: mono_image_get_table_info");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_table_info_get_rows", &symbol) == 0)
        memcpy(&g_prohenMono.table_info_get_rows, &symbol, sizeof(symbol));
    if (!g_prohenMono.table_info_get_rows) ProHENStatus("mono", "missing optional export: mono_table_info_get_rows");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_class_get", &symbol) == 0)
        memcpy(&g_prohenMono.class_get, &symbol, sizeof(symbol));
    if (!g_prohenMono.class_get) ProHENStatus("mono", "missing optional export: mono_class_get");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_class_get_name", &symbol) == 0)
        memcpy(&g_prohenMono.class_get_name, &symbol, sizeof(symbol));
    if (!g_prohenMono.class_get_name) ProHENStatus("mono", "missing optional export: mono_class_get_name");
    symbol = NULL;
    if (sceKernelDlsym(module, "mono_class_get_namespace", &symbol) == 0)
        memcpy(&g_prohenMono.class_get_namespace, &symbol, sizeof(symbol));
    if (!g_prohenMono.class_get_namespace) ProHENStatus("mono", "missing optional export: mono_class_get_namespace");
    g_optionalResolved = true;
    return true;
}

bool ProHENPanelAPIAvailable(void)
{
    return ProHENResolveMonoExtensions() && g_prohenMono.class_get_field_from_name && g_prohenMono.field_get_value;
}

bool ProHENMenuAPIAvailable(void)
{
    return ProHENPanelAPIAvailable() && g_prohenMono.class_get_methods && g_prohenMono.method_get_name &&
           g_prohenMono.method_signature && g_prohenMono.signature_get_param_count && g_prohenMono.signature_get_return_type &&
           g_prohenMono.type_get_type && g_prohenMono.method_get_flags && g_prohenMono.image_get_table_info &&
           g_prohenMono.table_info_get_rows && g_prohenMono.class_get && g_prohenMono.class_get_name && g_prohenMono.class_get_namespace;
}

bool ProHENVersionAPIAvailable(void)
{
    return ProHENResolveMonoExtensions() && g_prohenMono.method_signature && g_prohenMono.signature_get_param_count &&
           g_prohenMono.signature_get_return_type && g_prohenMono.type_get_type && g_prohenMono.method_get_flags;
}
