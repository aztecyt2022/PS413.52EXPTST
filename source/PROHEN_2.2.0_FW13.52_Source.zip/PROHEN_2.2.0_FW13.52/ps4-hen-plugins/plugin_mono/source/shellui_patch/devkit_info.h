#pragma once

#include <orbis/libkernel.h>
#include <stdbool.h>

bool RestoreFriendPanelName(void);

void UploadEventProxyCall(const struct OrbisKernelModuleInfo* info);
void UploadRegStrCall(const struct OrbisKernelModuleInfo* info, const struct OrbisKernelModuleInfo* app_exe);
