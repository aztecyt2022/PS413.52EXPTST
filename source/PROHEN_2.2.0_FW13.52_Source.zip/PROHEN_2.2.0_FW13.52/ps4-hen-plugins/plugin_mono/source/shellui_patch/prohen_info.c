/*
 * Append this build's identity to ShellUI's display-only firmware property.
 * The managed property is documented by OSM-Made's Orbis-Toolbox
 * UI_Utilities.cpp (SystemSoftwareVersionInfo.DisplayVersion).
 */
#include "prohen_info.h"
#include "../mono.h"
#include "../../../../prohen_version.h"
#include <stdio.h>
#include <string.h>

#ifndef PROHEN_INFO_TEST
#include <orbis/libkernel.h>
#endif

static bool ProHENInfoMethod(const void* method, uint32_t arguments,
                            bool is_static, int result_type)
{
    if (!method)
        return false;
    void* signature = mono_method_signature(method);
    void* result = signature ? mono_signature_get_return_type(signature) : NULL;
    int type = result ? mono_type_get_type(result) : 0;
    // Singleton<T>.Instance may retain its generic return type in Mono metadata.
    bool reference = type == 0x12 || type == 0x13 || type == 0x15 || type == 0x1c || type == 0x1e;
    return signature && mono_signature_get_param_count(signature) == arguments &&
           !!(mono_method_get_flags(method, NULL) & 0x10u) == is_static &&
           (result_type ? type == result_type : reference);
}

bool ProHENApplySystemVersion(void* app)
{
    if (!Root_Domain || !app)
        return false;
    OrbisKernelSwVersion firmware = {};
    firmware.Size = sizeof(firmware);
    if (sceKernelGetSystemSwVersion(&firmware) != 0 ||
        (firmware.Version & 0xffff0000u) != 0x13520000u)
        return false;

    void* klass = mono_class_from_name(app, "Sce.Vsh.ShellUI.AppSystem", "SystemSoftwareVersionInfo");
    if (!klass)
        return false;
    void* instance_property = mono_class_get_property_from_name(klass, "Instance");
    void* display_property = mono_class_get_property_from_name(klass, "DisplayVersion");
    if (!instance_property || !display_property)
        return false;
    void* instance_get = mono_property_get_get_method(instance_property);
    void* display_get = mono_property_get_get_method(display_property);
    void* display_set = mono_property_get_set_method(display_property);
    // Mono type tags: CLASS=0x12, STRING=0x0e, VOID=0x01.
    if (!ProHENInfoMethod(instance_get, 0, true, 0) ||
        !ProHENInfoMethod(display_get, 0, false, 0x0e) ||
        !ProHENInfoMethod(display_set, 1, false, 0x01))
        return false;

    const void* exception = NULL;
    void* instance = mono_runtime_invoke(instance_get, NULL, NULL, &exception);
    if (exception || !instance)
        return false;
    void* original = mono_runtime_invoke(display_get, instance, NULL, &exception);
    if (exception || !original)
        return false;
    char* native_text = mono_string_to_utf8(original);
    if (!native_text)
        return false;

    char display[160] = {};
    const char* previous = strstr(native_text, " | " PROHEN_NAME " ");
    size_t native_length = previous ? (size_t)(previous - native_text) : strlen(native_text);
    bool valid = native_length > 0 && native_length < sizeof(display);
    if (valid)
    {
        int length = snprintf(display, sizeof(display), "%.*s | %s", (int)native_length,
                              native_text, PROHEN_DISPLAY_NAME);
        valid = length > 0 && (size_t)length < sizeof(display);
    }
    bool already_set = valid && strcmp(display, native_text) == 0;
    mono_free(native_text);
    if (!valid || already_set)
        return already_set;

    void* branded = mono_string_new(Root_Domain, display);
    if (!branded)
        return false;
    const void* arguments[] = {branded};
    mono_runtime_invoke(display_set, instance, arguments, &exception);
    bool applied = !exception;
    if (applied)
    {
        void* result = mono_runtime_invoke(display_get, instance, NULL, &exception);
        char* text = !exception && result ? mono_string_to_utf8(result) : NULL;
        applied = text && strcmp(text, display) == 0;
        if (text)
            mono_free(text);
    }
    if (!applied)
    {
        // Restore the native display if the setter failed or changed the value unexpectedly.
        const void* restore[] = {original};
        exception = NULL;
        mono_runtime_invoke(display_set, instance, restore, &exception);
        printf("[PROHEN] System Information display update unavailable%s\n",
               exception ? "; native display restoration also failed" : "");
    }
    return applied;
}
