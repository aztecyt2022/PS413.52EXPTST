#pragma once

#include <stdint.h>
#include <orbis/libkernel.h>

#include "../../../common/path.h"

bool UploadOnBranch(void* app_exe, int app_exe_h);
void UploadNewCorelibStreamReader(void);
void UploadFinishBootEffectCode(const struct OrbisKernelModuleInfo* info);
