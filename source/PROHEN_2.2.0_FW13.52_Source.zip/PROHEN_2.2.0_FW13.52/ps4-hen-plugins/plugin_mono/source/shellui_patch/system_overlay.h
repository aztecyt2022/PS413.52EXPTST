#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

bool SystemOverlayInstall(void* app, uintptr_t text, size_t text_size);
bool SystemOverlayReady(void);
bool SystemOverlayMenuReady(void);
bool SystemOverlayToggle(void);
void SystemOverlayOnBoot(void);
bool SystemOverlayIsTitle(const wchar_t* key);
