#pragma once

#include <stdbool.h>

bool ProHENApplySystemVersion(void* app);
