/*
 * AZTEC System Overlay, an extension of Scene-Collective's MIT-licensed plugin_mono.
 * Native panel fields and Show/Hide/UITimer behavior are based on the published
 * Orbis-Toolbox DevkitPanel.cpp research by OSM-Made. No Orbis-Toolbox binary or
 * firmware-specific code offsets are copied.
 */
#include "system_overlay.h"
#include "../mono.h"
#include <string.h>
#include <wchar.h>
#include "../../../common/HDE/HDE64.h"

#ifndef AZTEC_OVERLAY_TEST
#include <orbis/libkernel.h>
#include <unistd.h>
#include "../../../common/memory.h"
#include "../../../common/notify.h"
#include "../mono_optional.h"
#include "../prohen_status.h"
#endif

static const char* kTopMenu = "Sce.Vsh.ShellUI.TopMenu";
static void* g_overlayArea;
static void* g_overlayPanelField;
static void* g_overlayTimerField;
static void* g_overlayCreate;
static void* g_overlayShow;
static void* g_overlayHide;
static void* g_overlayStart;
static void* g_overlayStop;
static bool g_overlayReady;
static bool g_overlayShown;
static bool g_overlayMenuReady;

static bool OverlayInvoke(const void* method, const void* object)
{
    if (!method || !object)
        return false;
    const void* exception = NULL;
    mono_runtime_invoke(method, object, NULL, &exception);
    if (exception)
        printf("[AZTEC overlay] managed call failed\n");
    return !exception;
}

static void* OverlayMethod(void* klass, const char* name)
{
    return klass ? mono_class_get_method_from_name(klass, name, 0) : NULL;
}

static void* OverlayField(const void* object, const void* field)
{
    void* value = NULL;
    if (object && field)
        mono_field_get_value(object, field, &value);
    return value;
}

static void* OverlayAreaInstance(void)
{
    if (!g_overlayArea)
        return NULL;
    void* property = mono_class_get_property_from_name(g_overlayArea, "Instance");
    void* method = property ? mono_property_get_get_method(property) : NULL;
    if (!method)
        return NULL;
    const void* exception = NULL;
    void* instance = mono_runtime_invoke(method, NULL, NULL, &exception);
    return exception ? NULL : instance;
}

static bool OverlaySetVisible(bool visible)
{
    if (!g_overlayReady)
        return false;
    void* area = OverlayAreaInstance();
    if (!area)
        return false;
    void* panel = OverlayField(area, g_overlayPanelField);
    if (!panel && visible)
    {
        if (!OverlayInvoke(g_overlayCreate, area))
            return false;
        panel = OverlayField(area, g_overlayPanelField);
    }
    void* timer = OverlayField(area, g_overlayTimerField);
    if (!visible && !panel)
    {
        g_overlayShown = false;
        return !timer || OverlayInvoke(g_overlayStop, timer);
    }
    if (!panel)
        return false;
    if (visible)
    {
        // Creation may have started the native timer already. Start is idempotent.
        if (!timer || !OverlayInvoke(g_overlayShow, panel) || !OverlayInvoke(g_overlayStart, timer))
        {
            OverlayInvoke(g_overlayHide, panel);
            if (timer) OverlayInvoke(g_overlayStop, timer);
            g_overlayShown = false;
            return false;
        }
    }
    else
    {
        if (timer && !OverlayInvoke(g_overlayStop, timer))
            return false;
        if (!OverlayInvoke(g_overlayHide, panel))
            return false;
    }
    g_overlayShown = visible;
    return true;
}

bool SystemOverlayReady(void) { return g_overlayReady; }
bool SystemOverlayMenuReady(void) { return g_overlayMenuReady; }

bool SystemOverlayToggle(void)
{
    if (!OverlaySetVisible(!g_overlayShown))
    {
        Notify("", "System Overlay unavailable. See /data/hen/prohen-status.log.");
        return false;
    }
    return true;
}

void SystemOverlayOnBoot(void)
{
    if (g_overlayReady && !OverlaySetVisible(false))
        printf("[AZTEC overlay] panel reset deferred until first selection\n");
}

bool SystemOverlayIsTitle(const wchar_t* key)
{
    // TopMenuPlugin alone calls this. Keep friend requests and notifications intact.
    if (!g_overlayMenuReady || !key)
        return false;
    return wcscmp(key, L"msg_friend") == 0 || wcscmp(key, L"msg_friends") == 0 ||
           wcscmp(key, L"msg_friend_long") == 0 || wcscmp(key, L"msg_friends_long") == 0 ||
           wcscmp(key, L"msg_friend_title") == 0 || wcscmp(key, L"msg_friends_title") == 0;
}

static void OverlayFriendSelected(void* instance)
{
    (void)instance;
    SystemOverlayToggle();
}

static void* OverlayFindFriendMethod(void* app)
{
    // Resolve from actual managed metadata rather than firmware memory offsets or
    // an assumed Friend/Friends class spelling. Require one declared instance
    // LaunchPlugin() returning void in the TopMenu SystemAreaIconFriend family.
    const void* table = mono_image_get_table_info(app, 2); // ECMA-335 TypeDef table.
    const int count = table ? mono_table_info_get_rows(table) : 0;
    if (count <= 0 || count > 50000)
        return NULL;
    void* selected = NULL;
    for (int row = 1; row <= count; ++row)
    {
        void* klass = mono_class_get(app, 0x02000000u | (uint32_t)row);
        if (!klass)
            continue;
        const char* ns = mono_class_get_namespace(klass);
        const char* name = mono_class_get_name(klass);
        if (!ns || !name || strcmp(ns, kTopMenu) ||
            (strcmp(name, "SystemAreaIconFriend") && strcmp(name, "SystemAreaIconFriends")))
            continue;
        void* iterator = NULL;
        void* method;
        while ((method = mono_class_get_methods(klass, &iterator)))
        {
            const char* method_name = mono_method_get_name(method);
            if (!method_name || strcmp(method_name, "LaunchPlugin"))
                continue;
            const void* signature = mono_method_signature(method);
            uint32_t impl_flags = 0;
            const uint32_t flags = mono_method_get_flags(method, &impl_flags);
            const void* return_type = signature ? mono_signature_get_return_type(signature) : NULL;
            if (!signature || !return_type || (flags & 0x0010u) || mono_signature_get_param_count(signature) != 0 ||
                mono_type_get_type(return_type) != 0x01)
                continue;
            if (selected)
                return NULL; // Ambiguous metadata: do not patch either method.
            selected = method;
        }
    }
    return selected;
}

static bool OverlayInitializePanel(void* app)
{
    if (g_overlayReady)
        return true;
    OrbisKernelSwVersion version = {};
    version.Size = sizeof(version);
    if (sceKernelGetSystemSwVersion(&version) != 0 || (version.Version & 0xffff0000u) != 0x13520000u)
        return false;
    if (!app || !Root_Domain)
        return false;
#ifndef AZTEC_OVERLAY_TEST
    if (!ProHENPanelAPIAvailable())
    {
        ProHENStatus("overlay", "panel field APIs unavailable; menu remains usable");
        return false;
    }
#endif
    g_overlayArea = mono_class_from_name(app, kTopMenu, "AreaManager");
    if (!g_overlayArea)
        return false;
    g_overlayPanelField = mono_class_get_field_from_name(g_overlayArea, "m_devKitPanel");
    g_overlayTimerField = mono_class_get_field_from_name(g_overlayArea, "m_updatePanelTimer");
    g_overlayCreate = OverlayMethod(g_overlayArea, "createDevKitPanel");

    const char* sandbox = sceKernelGetFsSandboxRandomWord();
    if (!sandbox || !sandbox[0])
        return false;
    char path[260];
    g_overlayShow = g_overlayHide = g_overlayStart = g_overlayStop = NULL;
    const char* assemblies[] = {"Sce.PlayStation.PUI.dll", "Sce.PlayStation.HighLevel.UI2.dll"};
    const char* namespaces[] = {"Sce.PlayStation.PUI", "Sce.PlayStation.HighLevel.UI2"};
    for (size_t i = 0; i < 2; ++i)
    {
        snprintf(path, sizeof(path), "/%s/common/lib/%s", sandbox, assemblies[i]);
        void* ui = mono_get_image(path);
        if (!ui) continue;
        void* node = mono_class_from_name(ui, namespaces[i], "UINode");
        void* timer = mono_class_from_name(ui, namespaces[i], "UITimer");
        g_overlayShow = OverlayMethod(node, "Show");
        g_overlayHide = OverlayMethod(node, "Hide");
        g_overlayStart = OverlayMethod(timer, "Start");
        g_overlayStop = OverlayMethod(timer, "Stop");
        if (g_overlayShow && g_overlayHide && g_overlayStart && g_overlayStop) break;
    }
    if (!g_overlayCreate || !g_overlayPanelField || !g_overlayTimerField ||
        !g_overlayShow || !g_overlayHide || !g_overlayStart || !g_overlayStop ||
        !mono_class_get_property_from_name(g_overlayArea, "Instance"))
    {
#ifndef AZTEC_OVERLAY_TEST
        ProHENStatus("overlay", "binding missing: panel=%d timer=%d create=%d show=%d hide=%d start=%d stop=%d",
                     !!g_overlayPanelField, !!g_overlayTimerField, !!g_overlayCreate,
                     !!g_overlayShow, !!g_overlayHide, !!g_overlayStart, !!g_overlayStop);
#endif
        return false;
    }
    g_overlayReady = true;
    g_overlayShown = false;
#ifndef AZTEC_OVERLAY_TEST
    ProHENStatus("overlay", "panel controls ready; Friends hook is a separate step");
#endif
    return true;
}

bool SystemOverlayInstall(void* app, uintptr_t text, size_t text_size)
{
    if (!OverlayInitializePanel(app)) return false;
    if (g_overlayMenuReady) return true;
    if (!text || text_size < 32) return false;
#ifndef AZTEC_OVERLAY_TEST
    if (!ProHENMenuAPIAvailable())
    {
        ProHENStatus("overlay", "Friends metadata unavailable; use PROHEN Settings > System Overlay");
        return false;
    }
#endif
    void* friend_method = OverlayFindFriendMethod(app);
    if (!friend_method)
    {
#ifndef AZTEC_OVERLAY_TEST
        ProHENStatus("overlay", "Friends LaunchPlugin method missing or ambiguous; Settings toggle retained");
#endif
        return false;
    }
    const uintptr_t target = (uintptr_t)mono_aot_get_method(Root_Domain, friend_method);
    if (target < text || target - text > text_size - 32)
        return false;
    // A short return/thunk must not let our 14-byte jump overwrite the next
    // native method. The same HDE decoder is already used by upstream hooks.
    size_t covered = 0;
    while (covered < 14)
    {
        hde64s instruction = {};
        const unsigned int length = hde64_disasm((const void*)(target + covered), &instruction);
        if (!length || (instruction.flags & F_ERROR) || instruction.opcode == 0xc3 ||
            instruction.opcode == 0xc2 || instruction.opcode == 0xcc ||
            instruction.opcode == 0xe9 || instruction.opcode == 0xeb ||
            (instruction.opcode == 0xff && instruction.modrm_reg == 4))
            return false;
        covered += length;
    }
    uint8_t original[14];
    memcpy(original, (const void*)target, sizeof(original));
    uint8_t patch[14] = {0xff, 0x25, 0, 0, 0, 0};
    const uintptr_t hook = (uintptr_t)OverlayFriendSelected;
    memcpy(patch + 6, &hook, sizeof(hook));
    sys_proc_rw(getpid(), target, patch, sizeof(patch), 1);
    if (memcmp((const void*)target, patch, sizeof(patch)) || !RestoreFriendPanelName())
    {
        sys_proc_rw(getpid(), target, original, sizeof(original), 1);
        printf("[AZTEC overlay] Friends hook write unavailable; panel controls remain ready\n");
        return false;
    }
    g_overlayMenuReady = true;
    g_overlayShown = false;
    printf("[AZTEC overlay] Friends entry bound to native system panel\n");
    return true;
}
