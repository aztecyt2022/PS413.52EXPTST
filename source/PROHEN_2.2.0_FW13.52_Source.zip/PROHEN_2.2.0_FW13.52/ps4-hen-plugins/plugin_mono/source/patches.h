#pragma once

extern "C"
{
#include "shellui_patch/devkit_info.h"
#include "shellui_patch/system_overlay.h"
#include "shellui_patch/prohen_info.h"
#include "shellui_patch/settings_menu.h"
#include "shellui_patch/remoteplay.h"
#include "shellui_patch/debug_settings.h"
};
