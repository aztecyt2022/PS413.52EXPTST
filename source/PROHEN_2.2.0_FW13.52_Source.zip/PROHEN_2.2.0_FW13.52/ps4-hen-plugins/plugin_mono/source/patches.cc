extern "C"
{
#include "shellui_patch/devkit_info.c"
#include "shellui_patch/system_overlay.c"
#include "shellui_patch/prohen_info.c"
#include "shellui_patch/settings_menu.c"
#include "shellui_patch/remoteplay.c"
#include "shellui_patch/debug_settings.c"
};
