#pragma once

void ProHENStatus(const char* stage, const char* format, ...);
