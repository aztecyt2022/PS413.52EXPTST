#pragma once
#include <stdbool.h>

bool ProHENTryInitializeShellUI(int app_handle);
