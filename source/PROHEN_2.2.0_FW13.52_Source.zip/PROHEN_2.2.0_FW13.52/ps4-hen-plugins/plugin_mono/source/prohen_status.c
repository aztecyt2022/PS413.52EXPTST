#include "prohen_status.h"
#include "../../common/file.h"
#include "../../common/path.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <pthread.h>

void ProHENStatus(const char* stage, const char* format, ...)
{
    static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
    static char history[8192];
    static char previous[384];
    char detail[256], line[384];
    va_list args;
    va_start(args, format);
    vsnprintf(detail, sizeof(detail), format, args);
    va_end(args);
    snprintf(line, sizeof(line), "[PROHEN][%s] %s\n", stage, detail);
    pthread_mutex_lock(&lock);
    if (strcmp(previous, line))
    {
        size_t used = strlen(history), length = strlen(line);
        while (used + length >= sizeof(history))
        {
            char* end = strchr(history, '\n');
            if (!end) { history[0] = 0; used = 0; break; }
            size_t removed = (size_t)(end + 1 - history);
            memmove(history, history + removed, used - removed + 1);
            used -= removed;
        }
        memcpy(history + used, line, length + 1);
        memcpy(previous, line, length + 1);
        printf("%s", line);
        write_file(BASE_PATH "/prohen-status.log", history, used + length);
    }
    pthread_mutex_unlock(&lock);
}
