"""Guard the native plugin's optional-feature import boundary."""
import re
import subprocess
import sys
from pathlib import Path

header = Path(__file__).parent.parent / "plugin_mono/source/mono_optional.h"
optional = set(re.findall(r"^#define (mono_\w+) ", header.read_text(), re.MULTILINE))
symbols = subprocess.check_output(["readelf", "-Ws", sys.argv[1]], text=True)
imports = {line.split()[-1] for line in symbols.splitlines() if " UND " in line}
assert len(optional) == 14
assert not optional & imports, f"Optional APIs became mandatory: {optional & imports}"
assert {"mono_get_root_domain", "mono_runtime_invoke"} <= imports, "Core Mono imports missing"
print("PASS: 14 optional Mono APIs are excluded from mandatory imports; core Mono imports remain.")
