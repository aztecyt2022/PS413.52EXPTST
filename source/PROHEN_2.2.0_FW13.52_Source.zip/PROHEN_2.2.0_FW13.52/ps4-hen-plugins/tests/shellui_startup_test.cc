#include <cassert>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include "../plugin_mono/source/shellui_startup.c"

static int domain, app;
void* Root_Domain;
void* App_Exe;
void* MSCorlib;
static bool have_domain, have_app, have_hooks, reenter;
static unsigned domain_calls, image_calls, hook_calls, package_calls;

void* mono_get_root_domain() { ++domain_calls; return have_domain?&domain:nullptr; }
void* mono_get_image(const char*) { ++image_calls; assert(Root_Domain); return have_app?&app:nullptr; }
bool UploadOnBranch(void* image, int handle) {
    assert(image==&app && handle==8381); ++hook_calls;
    if(reenter) assert(!ProHENTryInitializeShellUI(handle));
    return have_hooks;
}
void UploadNewPkgInstallerPath(void* image,int handle) { assert(image==&app&&handle==8381);++package_calls; }
void ProHENStatus(const char*,const char*,...) {}
static void reset() {
    Root_Domain=App_Exe=nullptr;g_startupReady=false;g_startupBusy=0;
    have_domain=have_app=have_hooks=reenter=false;
    domain_calls=image_calls=hook_calls=package_calls=0;
}
int main() {
    reset();have_domain=have_app=have_hooks=true;
    assert(ProHENTryInitializeShellUI(8381));assert(domain_calls==1&&image_calls==1&&hook_calls==1&&package_calls==1);
    assert(ProHENTryInitializeShellUI(8381));assert(hook_calls==1&&package_calls==1);
    reset();assert(!ProHENTryInitializeShellUI(0));assert(domain_calls==0);
    assert(!ProHENTryInitializeShellUI(8381));assert(domain_calls==1&&image_calls==0);
    have_domain=true;assert(!ProHENTryInitializeShellUI(8381));assert(image_calls==1&&hook_calls==0);
    have_app=true;assert(!ProHENTryInitializeShellUI(8381));assert(App_Exe&&hook_calls==1&&package_calls==0);
    have_hooks=true;reenter=true;assert(ProHENTryInitializeShellUI(8381));assert(hook_calls==2&&package_calls==1);
    puts("PASS: initialization can finish on the first available event, retries delayed metadata even with an existing image, blocks recursive entry, and stops after verified installation.");
}
