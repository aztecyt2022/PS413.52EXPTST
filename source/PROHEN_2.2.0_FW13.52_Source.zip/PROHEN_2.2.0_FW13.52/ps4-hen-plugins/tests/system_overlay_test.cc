#include <cassert>
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>
#include <cstdarg>
#include <unistd.h>
#include <string>
#include <vector>

struct OrbisKernelSwVersion { size_t Size; char VersionString[28]; uint32_t Version; };
static int sceKernelGetSystemSwVersion(OrbisKernelSwVersion*);
static const char* sceKernelGetFsSandboxRandomWord();
static int sys_proc_rw(int, uintptr_t, const void*, uint64_t, uint64_t);
static void Notify(const char*, const char*, ...);
static bool RestoreFriendPanelName();
#define AZTEC_OVERLAY_TEST
#include "../plugin_mono/source/shellui_patch/system_overlay.c"
extern "C" {
#include "../common/HDE/HDE64.c"
}

struct Method { const char* name; uint32_t args = 0, flags = 0; int type = 1; };
static Method instance{"get_Instance"}, create{"createDevKitPanel"}, show{"Show"}, hide{"Hide"}, start{"Start"}, stop{"Stop"}, launch{"LaunchPlugin"};
static int app, ui, area, node, timer_class, friends, friends2, panel_field, timer_field, area_object, panel_object, timer_object;
void* Root_Domain = &app;
void* App_Exe = &app;
void* MSCorlib = nullptr;
static uint8_t code[128];
static uint32_t firmware;
static bool missing_ui, missing_method, duplicate, restore_ok, field_exists, timer_exists, fail_write;
static bool panel_visible, timer_running;
static Method* throw_method;
static unsigned int writes, creates, notices;
static uintptr_t native_target;

static int sceKernelGetSystemSwVersion(OrbisKernelSwVersion* v) { v->Version=firmware; return 0; }
static const char* sceKernelGetFsSandboxRandomWord() { return "sandbox"; }
static int sys_proc_rw(int, uintptr_t target, const void* data, uint64_t size, uint64_t) {
    ++writes; if (fail_write && writes==1) size=1;
    memcpy(reinterpret_cast<void*>(target),data,size); return 0;
}
static void Notify(const char*, const char*, ...) { ++notices; }
static bool RestoreFriendPanelName() { return restore_ok; }
void* mono_class_from_name(const void*, const char*, const char* name) {
    if (!strcmp(name,"AreaManager")) return &area;
    if (!strcmp(name,"UINode")) return &node;
    if (!strcmp(name,"UITimer")) return &timer_class;
    return nullptr;
}
void* mono_class_get_field_from_name(const void*,const char* name) { return !strcmp(name,"m_devKitPanel") ? &panel_field : &timer_field; }
void mono_field_get_value(const void*,const void* field,void* out) {
    *static_cast<void**>(out)=field==&panel_field ? (field_exists?&panel_object:nullptr) : (timer_exists?&timer_object:nullptr);
}
void* mono_class_get_property_from_name(const void*,const char*) { return &instance; }
void* mono_property_get_get_method(const void* p) { return const_cast<void*>(p); }
void* mono_class_get_method_from_name(const void*,const char* name,int) {
    if (missing_method) return nullptr;
    for (auto p:{&create,&show,&hide,&start,&stop}) if (!strcmp(p->name,name)) return p;
    return nullptr;
}
void* mono_get_image(const char*) { return missing_ui?nullptr:&ui; }
const void* mono_image_get_table_info(const void*,int) { return &app; }
int mono_table_info_get_rows(const void*) { return duplicate?2:1; }
void* mono_class_get(const void*,uint32_t token) { return (token&0xffffff)==1?&friends:&friends2; }
const char* mono_class_get_name(const void* klass) { return klass==&friends?"SystemAreaIconFriend":"SystemAreaIconFriends"; }
const char* mono_class_get_namespace(const void*) { return "Sce.Vsh.ShellUI.TopMenu"; }
void* mono_class_get_methods(const void*,void** iter) { if(*iter)return nullptr;*iter=&app;return &launch; }
const char* mono_method_get_name(const void* p) { return static_cast<const Method*>(p)->name; }
void* mono_method_signature(const void* p) { return const_cast<void*>(p); }
uint32_t mono_signature_get_param_count(const void* p) { return static_cast<const Method*>(p)->args; }
void* mono_signature_get_return_type(const void* p) { return const_cast<void*>(p); }
int mono_type_get_type(const void* p) { return static_cast<const Method*>(p)->type; }
uint32_t mono_method_get_flags(const void* p,uint32_t*) { return static_cast<const Method*>(p)->flags; }
void* mono_aot_get_method(const void*,const void*) { return reinterpret_cast<void*>(native_target); }
void* mono_runtime_invoke(const void* p,const void*,const void*[],const void* exc[]) {
    if (p==throw_method) { *exc=&app;return nullptr; }
    if (p==&instance) return &area_object;
    if (p==&create) { field_exists=true;timer_exists=true;++creates; }
    if (p==&show) panel_visible=true;
    if (p==&hide) panel_visible=false;
    if (p==&start) timer_running=true;
    if (p==&stop) timer_running=false;
    return nullptr;
}

static void reset() {
    g_overlayReady=false;g_overlayShown=false;g_overlayArea=nullptr;
    firmware=0x13520001u;Root_Domain=&app;
    missing_ui=missing_method=duplicate=field_exists=timer_exists=fail_write=false;
    panel_visible=timer_running=false;restore_ok=true;throw_method=nullptr;
    writes=creates=notices=0;memset(code,0x90,sizeof(code));native_target=reinterpret_cast<uintptr_t>(code);
    launch={"LaunchPlugin",0,0,1};
}
static bool install() { return SystemOverlayInstall(&app,reinterpret_cast<uintptr_t>(code),sizeof(code)); }
static void original() { for(auto b:code)assert(b==0x90); }

int main() {
    reset();assert(install());assert(SystemOverlayReady());assert(writes==1);
    SystemOverlayOnBoot();assert(creates==0);assert(!panel_visible&&!timer_running);
    assert(SystemOverlayIsTitle(L"msg_friend"));assert(!SystemOverlayIsTitle(L"msg_friend_request"));
    assert(!SystemOverlayIsTitle(nullptr));
    assert(SystemOverlayToggle());assert(panel_visible&&timer_running&&creates==1);
    assert(SystemOverlayToggle());assert(!panel_visible&&!timer_running&&creates==1);
    assert(SystemOverlayToggle());assert(panel_visible&&timer_running&&creates==1);
    SystemOverlayOnBoot();assert(!panel_visible&&!timer_running);
    assert(install());assert(writes==1);
    puts("PASS: native panel toggles, refresh timer stops, panel is reused, boot is hidden, install is idempotent.");
    reset();firmware=0x13500000u;assert(!install());assert(writes==0);original();
    reset();firmware=0x14000000u;assert(!install());assert(writes==0);original();
    reset();missing_ui=true;assert(!install());assert(writes==0);original();
    reset();missing_method=true;assert(!install());assert(writes==0);original();
    reset();Root_Domain=nullptr;assert(!install());assert(writes==0);original();
    reset();duplicate=true;assert(!install());assert(writes==0);original();
    reset();launch.args=1;assert(!install());assert(writes==0);original();
    reset();launch.flags=0x10;assert(!install());assert(writes==0);original();
    reset();launch.type=8;assert(!install());assert(writes==0);original();
    reset();native_target+=120;assert(!install());assert(writes==0);original();
    reset();code[4]=0xc3;assert(!install());assert(writes==0);
    puts("PASS: unsupported firmware, missing metadata, ambiguous/incorrect methods, invalid ranges and short functions perform no patches.");
    reset();restore_ok=false;assert(!install());assert(writes==2);original();assert(!SystemOverlayReady());
    reset();fail_write=true;assert(!install());assert(writes==2);original();assert(!SystemOverlayReady());
    puts("PASS: failed native writes and failed Friends restoration roll the method patch back.");
    reset();assert(install());throw_method=&show;assert(!SystemOverlayToggle());
    assert(!panel_visible&&!timer_running&&!g_overlayShown&&notices==1);
    reset();assert(!SystemOverlayToggle());assert(notices==1&&writes==0);
    puts("PASS: managed errors close the overlay, stop its timer, and produce feedback.");
}
