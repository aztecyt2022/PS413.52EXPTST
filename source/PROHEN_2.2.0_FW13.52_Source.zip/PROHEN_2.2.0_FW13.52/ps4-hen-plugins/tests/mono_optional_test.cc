#include <cassert>
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstring>
typedef int32_t OrbisKernelModule;
static int sceKernelGetModuleList(OrbisKernelModule*,size_t,size_t*);
static int sceKernelDlsym(int,const char*,void**);
#define PROHEN_OPTIONAL_TEST
#include "../plugin_mono/source/mono_optional.c"

static bool list_error, module_missing;
static const char* missing;
static unsigned notices;
static void dummy() {}
static int sceKernelGetModuleList(OrbisKernelModule* out,size_t capacity,size_t* count) {
    assert(capacity==512);if(list_error)return -1;*count=2;out[0]=2;out[1]=8381;return 0;
}
static int sceKernelDlsym(int handle,const char* symbol,void** out) {
    if(module_missing || handle!=8381 || (missing&&!strcmp(missing,symbol)))return -1;
    *out=reinterpret_cast<void*>(dummy);return 0;
}
void ProHENStatus(const char*,const char*,...) { ++notices; }
static void reset() {
    memset(&g_prohenMono,0,sizeof(g_prohenMono));g_optionalResolved=false;
    list_error=module_missing=false;missing=nullptr;notices=0;
}
int main() {
    reset();assert(ProHENPanelAPIAvailable()&&ProHENMenuAPIAvailable()&&ProHENVersionAPIAvailable());
    reset();missing="mono_class_get";assert(ProHENPanelAPIAvailable()&&ProHENVersionAPIAvailable());assert(!ProHENMenuAPIAvailable());assert(notices==1);
    reset();missing="mono_method_signature";assert(ProHENPanelAPIAvailable());assert(!ProHENMenuAPIAvailable()&&!ProHENVersionAPIAvailable());
    reset();missing="mono_field_get_value";assert(!ProHENPanelAPIAvailable()&&!ProHENMenuAPIAvailable());assert(ProHENVersionAPIAvailable());
    reset();module_missing=true;assert(!ProHENResolveMonoExtensions());module_missing=false;assert(ProHENResolveMonoExtensions());
    reset();list_error=true;assert(!ProHENResolveMonoExtensions());list_error=false;assert(ProHENResolveMonoExtensions());
    puts("PASS: optional missing exports disable only dependent features; module discovery supports large handles and retries unavailable module lists.");
}
