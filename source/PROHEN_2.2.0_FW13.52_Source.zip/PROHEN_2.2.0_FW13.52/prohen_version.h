#pragma once

// Shared by the installer and ShellUI plugin so displayed versions agree.
#define PROHEN_NAME "PROHEN"
#define PROHEN_VERSION "2.2.0 BETA"
#define PROHEN_DISPLAY_NAME PROHEN_NAME " " PROHEN_VERSION
#define PROHEN_BUILD "custom build 2"
